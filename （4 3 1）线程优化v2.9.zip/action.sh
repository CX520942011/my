#!/system/bin/sh
#(此代码源自于@Afaraway)
CLOUD_MODULE_PROP="https://gitee.com/love-to-eat-small-dumplings/magisk-configs/raw/master/modul.prop"
CLOUD_CHANGELOG="https://gitee.com/love-to-eat-small-dumplings/magisk-configs/raw/master/AdaptationListlog.md"
CLOUD_APP_LIST="https://gitee.com/love-to-eat-small-dumplings/magisk-configs/raw/master/applist.conf"
MODULE_PATH="/data/adb/modules/AppOpt"
MODULE_PROP="${MODULE_PATH}/modul.prop"
APP_LIST="${MODULE_PATH}/applist.conf"
TMP_DIR="/storage/emulated/0/Download"
TMP_APP_LIST="${TMP_DIR}/applist.conf"

log_prefix() {
    echo "[$(date "+%Y-%m-%d %H:%M:%S")]"
}

log_with_timestamp() {
    while IFS= read -r line; do
        echo "$(log_prefix) ${line}"
    done
}

cleanup() {
    echo "$(log_prefix) 缓存已清理..."
    echo "$(log_prefix) 更新流程结束"
    echo "----------------------------------------"
    rm -f "${TMP_APP_LIST}" >/dev/null 2>&1
}
trap cleanup EXIT

download_with_busybox() {
    local url="$1"
    local output="$2"
    
    local busybox="/data/adb/magisk/busybox"
    
    if [ -x "${busybox}" ]; then
        if [ -z "$output" ]; then
            "${busybox}" wget -qO- "$url" 2>/dev/null && return 0
        else
            "${busybox}" wget -q "$url" -O "$output" 2>/dev/null && return 0
        fi
    fi
    
    return 1
}

download_file() {
    local url="$1"
    local output="$2"
    
    if command -v curl >/dev/null 2>&1; then
        if [ -z "$output" ]; then
            curl -fsL "$url" 2>/dev/null && return 0
        else
            curl -fsL "$url" -o "$output" 2>/dev/null && return 0
        fi
    fi
    
    if command -v wget >/dev/null 2>&1; then
        if [ -z "$output" ]; then
            wget -qO- "$url" 2>/dev/null && return 0
        else
            wget -q "$url" -O "$output" 2>/dev/null && return 0
        fi
    fi
    
    download_with_busybox "$url" "$output" && return 0
    
    echo "$(log_prefix) 错误：无法下载文件，curl、wget、BusyBox等下载方式均不可用！"
    return 1
}

volume_key_selector() {
    local timeout=15
    local start_time=$(date +%s)
    local key_detected=""
    
    echo "$(log_prefix) 请选择操作："
    echo "$(log_prefix) [音量+] 确认更新  [音量-] 取消更新"
    echo "$(log_prefix) 等待用户选择（15秒后自动取消）..."
    
    while [ -z "$key_detected" ]; do
        local current_time=$(date +%s)
        if [ $((current_time - start_time)) -ge $timeout ]; then
            echo "$(log_prefix) 选择超时，自动取消更新"
            return 1
        fi
        
        local key_event=$(getevent -qlc 1 2>/dev/null | 
            awk 'BEGIN{FS=" "} /KEY_VOLUMEUP/{print "UP"; exit} /KEY_VOLUMEDOWN/{print "DOWN"; exit}')
        
        case "$key_event" in
            "UP")
                echo "$(log_prefix) 检测到音量上键"
                key_detected="confirm"
                ;;
            "DOWN")
                echo "$(log_prefix) 检测到音量下键"
                key_detected="cancel"
                ;;
        esac
        sleep 0.2
    done

    [ "$key_detected" = "confirm" ] && return 0 || return 1
}

echo "----------------------------------------"
echo "$(log_prefix) 正在获取设备信息..."
{
    echo "设备型号: $(getprop ro.product.model 2>/dev/null || echo '未知')"
    echo "安卓版本: $(getprop ro.build.version.release 2>/dev/null || echo '未知')"
    echo "系统构建: $(getprop ro.build.display.id 2>/dev/null || echo '未知')"
    magisk_path=$(which magisk 2>/dev/null || echo "/data/adb/magisk/magisk")
    echo "Magisk版本: $(${magisk_path} -v 2>/dev/null || echo '未知')"
} | log_with_timestamp

echo "----------------------------------------"
echo "$(log_prefix) 开始检查版本更新..."
cloud_prop=$(download_file "${CLOUD_MODULE_PROP}") || {
    echo "$(log_prefix) 错误：无法获取云端版本配置文件"
    exit 1
}

cloud_version=$(echo "${cloud_prop}" | grep '^versionCode=' | awk -F'=' '{print $2}')
if [ -z "${cloud_version}" ]; then
    echo "$(log_prefix) 错误：云端版本号格式异常"
    exit 1
fi
echo "$(log_prefix) 云端最新版本号：${cloud_version}"
if [ ! -f "${MODULE_PROP}" ]; then
    echo "$(log_prefix) 错误：本地模块配置文件不存在"
    exit 1
fi
local_version=$(grep '^versionCode=' "${MODULE_PROP}" | awk -F'=' '{print $2}')
if [ -z "${local_version}" ]; then
    echo "$(log_prefix) 错误：本地版本号解析失败"
    exit 1
fi
echo "$(log_prefix) 当前本地版本号：${local_version}"

if [ "${cloud_version}" -gt "${local_version}" ]; then
    echo "$(log_prefix) 检测到新版本"
    echo "$(log_prefix) 正在获取配置更新日志..."
    changelog=$(download_file "${CLOUD_CHANGELOG}") || {
        echo "$(log_prefix) 错误：更新日志获取失败"
        exit 1
    }
    echo "$(log_prefix) 更新日志内容："
    echo "----------------------------------------"
    echo "${changelog}" | log_with_timestamp
    echo "----------------------------------------"

    if volume_key_selector; then
        echo "$(log_prefix) 您已确认更新"
    else
        echo "$(log_prefix) 更新流程已取消"
        exit 0
    fi

    echo "$(log_prefix) 开始下载新版配置文件..."
    if ! download_file "${CLOUD_APP_LIST}" "${TMP_APP_LIST}"; then
        echo "$(log_prefix) 错误：配置文件下载失败"
        exit 1
    fi

    backup_name="applist.conf.bak"
    echo "$(log_prefix) 正在备份旧版配置文件..."
    if ! cp -f "${APP_LIST}" "${MODULE_PATH}/${backup_name}"; then
        echo "$(log_prefix) 错误：配置文件备份失败"
        exit 1
    fi

    echo "$(log_prefix) 正在应用新版配置文件..."
    if ! su -c "mv -f ${TMP_APP_LIST} ${APP_LIST}"; then
        echo "$(log_prefix) 错误：配置文件替换失败"
        exit 1
    fi

    echo "$(log_prefix) 正在更新本地版本号..."
    if ! sed -i "s/^versionCode=.*/versionCode=${cloud_version}/" "${MODULE_PROP}"; then
        echo "$(log_prefix) 错误：版本号更新失败"
        exit 1
    fi

    echo "$(log_prefix) 版本更新完成"
    echo "$(log_prefix) 已更新至：${cloud_version}"
else
    echo "$(log_prefix) 当前版本已是最新，无需更新"
fi