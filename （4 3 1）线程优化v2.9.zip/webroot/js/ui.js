// 界面交互功能

// 初始化UI事件
function initUI() {
    // 主题切换按钮
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }

    // 搜索框清除按钮
    const searchInput = document.getElementById('search-input');
    const clearSearch = document.getElementById('clear-search');

    if (searchInput && clearSearch) {
        // 输入内容时显示清除按钮
        searchInput.addEventListener('input', function() {
            if (this.value.length > 0) {
                clearSearch.classList.add('active');
            } else {
                clearSearch.classList.remove('active');
                updateBindingsList(); // 恢复显示所有应用
            }
        });

        // 点击清除按钮清空搜索内容
        clearSearch.addEventListener('click', function() {
            searchInput.value = '';
            clearSearch.classList.remove('active');
            updateBindingsList(); // 恢复显示所有应用
            searchInput.focus();
        });

        // 防抖搜索处理
        searchInput.addEventListener('input', debounce(handleSearch, 300));
    }

    // 底部导航按钮
    bindActionButtons();

    // 模态框事件
    initModals();

    // 初始化智能输入建议
    if (typeof initSuggestions === 'function') {
        initSuggestions();
    }

    // 初始化添加规则模态框
    initAddRuleModal();

    // 移动端滑动隐藏工具栏
    if (window.innerWidth <= 480) {
        initScrollHideToolbar();
    }

    // 列表加载完成后检查底部可见性
    ensureBottomItemsVisible();

    // 监听窗口大小变化
    window.addEventListener('resize', debounce(() => {
        if (window.innerWidth <= 480) {
            initScrollHideToolbar();
        }
        ensureBottomItemsVisible();
    }, 200));
}

// 绑定底部按钮事件
function bindActionButtons() {
    // 批量操作按钮
    const batchBtn = document.getElementById('batch-btn');
    if (batchBtn) {
        batchBtn.addEventListener('click', showBatchModal);
    }

    // 刷新按钮
    const refreshBtn = document.getElementById('refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', refreshBindingsList);
    }

    // 保存按钮
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', saveConfig);
    }

    // 添加应用按钮
    const addAppBtn = document.getElementById('add-app-btn');
    if (addAppBtn) {
        addAppBtn.addEventListener('click', showAddAppModal);
    }

    // 应用范围设置按钮
    const appScopeBtn = document.getElementById('app-scope-btn');
    if (appScopeBtn) {
        appScopeBtn.addEventListener('click', showAppScopeModal);
    }

    // 为底部工具栏按钮添加波纹效果
    addRippleEffect('.toolbar-btn');
}

// 初始化模态框事件
function initModals() {
    // 通用模态框关闭事件
    document.querySelectorAll('.modal-close').forEach(closeBtn => {
        const modal = closeBtn.closest('.modal');
        closeBtn.addEventListener('click', () => {
            hideModal(modal.id);
        });
    });

    // 添加应用模态框
    initAddAppModal();

    // 编辑绑定模态框
    initEditBindingModal();

    // 编辑应用名模态框
    initEditNameModal();

    // 批量操作模态框
    initBatchModal();

    // 应用范围设置模态框
    initAppScopeModal();

    // 确认对话框
    initConfirmDialog();
}

/**
 * 初始化添加应用模态框
 */
function initAddAppModal() {
    const modal = document.getElementById('add-app-modal');
    if (!modal) return;

    // 添加规则按钮
    const addRuleBtn = document.getElementById('add-rule-btn');
    if (addRuleBtn) {
        addRuleBtn.addEventListener('click', addProcessItem);
    }

    // 取消按钮
    const cancelBtn = document.getElementById('add-app-cancel');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => hideModal('add-app-modal'));
    }

    // 确认添加按钮
    const confirmBtn = document.getElementById('add-app-confirm');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', addNewApp);
    }

    // 绑定初始规则项的移除按钮
    bindRemoveProcessButtons();

    // 绑定初始规则项的类型切换功能
    bindBindingTypeEvents();
}

/**
 * 初始化添加规则模态框
 */
function initAddRuleModal() {
    const modal = document.getElementById('add-rule-modal');
    if (!modal) return;

    // 添加规则按钮
    const addRuleBtn = document.getElementById('add-rule-item-btn');
    if (addRuleBtn) {
        addRuleBtn.addEventListener('click', addRuleProcessItem);
    }

    // 取消按钮
    const cancelBtn = document.getElementById('add-rule-cancel');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => hideModal('add-rule-modal'));
    }

    // 确认添加按钮
    const confirmBtn = document.getElementById('add-rule-confirm');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', addNewRules);
    }

    // 关闭按钮
    const closeBtn = document.getElementById('close-add-rule-modal');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => hideModal('add-rule-modal'));
    }
}

/**
 * 初始化编辑绑定模态框
 */
function initEditBindingModal() {
    const modal = document.getElementById('edit-binding-modal');
    if (!modal) return;

    // 绑定类型选择变化事件
    const typeRadios = document.querySelectorAll('input[name="edit-binding-type"]');
    typeRadios.forEach(radio => {
        radio.addEventListener('change', toggleBindingTypeFields);
    });

    // 取消按钮
    const cancelBtn = document.getElementById('edit-binding-cancel');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => hideModal('edit-binding-modal'));
    }

    // 保存按钮
    const confirmBtn = document.getElementById('edit-binding-confirm');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', saveBindingChanges);
    }
}

/**
 * 初始化编辑应用名模态框
 */
function initEditNameModal() {
    const modal = document.getElementById('edit-name-modal');
    if (!modal) return;

    // 取消按钮
    const cancelBtn = document.getElementById('edit-name-cancel');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => hideModal('edit-name-modal'));
    }

    // 保存按钮
    const confirmBtn = document.getElementById('edit-name-confirm');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', saveAppName);
    }
}

/**
 * 初始化批量操作模态框
 */
function initBatchModal() {
    const modal = document.getElementById('batch-modal');
    if (!modal) return;

    // 批量操作模态框关闭事件
    const closeBatchBtn = document.getElementById('close-batch-modal');
    const batchCloseBtn = document.getElementById('batch-close-btn');
    if (closeBatchBtn) {
        closeBatchBtn.addEventListener('click', () => hideModal('batch-modal'));
    }
    if (batchCloseBtn) {
        batchCloseBtn.addEventListener('click', () => hideModal('batch-modal'));
    }

    // 批量操作控制按钮
    const selectAllBtn = document.getElementById('select-all-btn');
    const selectNoneBtn = document.getElementById('select-none-btn');
    const batchEnableBtn = document.getElementById('batch-enable-btn');
    const batchDisableBtn = document.getElementById('batch-disable-btn');

    if (selectAllBtn) {
        selectAllBtn.addEventListener('click', selectAllApps);
    }
    if (selectNoneBtn) {
        selectNoneBtn.addEventListener('click', selectNoneApps);
    }
    if (batchEnableBtn) {
        batchEnableBtn.addEventListener('click', batchEnableApps);
    }
    if (batchDisableBtn) {
        batchDisableBtn.addEventListener('click', batchDisableApps);
    }
}

/**
 * 初始化应用范围设置模态框
 */
function initAppScopeModal() {
    const modal = document.getElementById('app-scope-modal');
    if (!modal) return;

    // 取消按钮
    const cancelBtn = document.getElementById('app-scope-cancel');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => hideModal('app-scope-modal'));
    }

    // 确认按钮
    const confirmBtn = document.getElementById('app-scope-confirm');
    if (confirmBtn) {
        confirmBtn.addEventListener('click', confirmAppScope);
    }
}

/**
 * 初始化确认对话框
 */
function initConfirmDialog() {
    const dialog = document.getElementById('confirm-dialog');
    if (!dialog) return;

    // 取消按钮
    const cancelBtn = document.getElementById('confirm-cancel');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', hideConfirmDialog);
    }
}

/**
 * 处理搜索功能
 */
function handleSearch() {
    const searchText = document.getElementById('search-input').value.trim().toLowerCase();
    updateBindingsList(searchText);
}

/**
 * 显示指定ID的模态框
 * @param {string} modalId - 模态框ID
 */
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

/**
 * 隐藏指定ID的模态框
 * @param {string} modalId - 模态框ID
 */
function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

/**
 * 显示添加应用模态框
 */
function showAddAppModal() {
    // 重置表单
    const nameInput = document.getElementById('new-app-name');
    const packageInput = document.getElementById('new-app-package');

    if (nameInput) nameInput.value = '';
    if (packageInput) {
        packageInput.value = '';
        packageInput.readOnly = false; // 确保包名输入框可编辑
    }

    // 重置规则列表
    resetProcessList();

    // 显示模态框
    showModal('add-app-modal');

    // 延迟重新绑定事件，确保DOM已更新
    setTimeout(() => {
        // 重新绑定绑定类型事件
        bindBindingTypeEvents();

        // 重新初始化应用名称补全
        if (typeof setupAppNameInput === 'function') {
            setupAppNameInput('#new-app-name', '#new-app-package');
        }
    }, 50);
}

/**
 * 重置规则列表
 */
function resetProcessList() {
    const processList = document.getElementById('process-list');
    if (!processList) return;

    // 清空现有规则
    processList.innerHTML = '';

    // 添加一个默认规则项
    const template = document.createElement('template');
    template.innerHTML = createProcessItemHtml().trim();
    const newItem = template.content.cloneNode(true);
    processList.appendChild(newItem);

    // 重新绑定移除按钮事件
    bindRemoveProcessButtons();

    // 为新添加的规则项设置初始状态（主进程选中，名称输入框隐藏）
    const firstItem = processList.querySelector('.process-item');
    if (firstItem) {
        const mainRadio = firstItem.querySelector('input[value="main"]');
        const nameGroup = firstItem.querySelector('.binding-name-group');

        if (mainRadio) {
            mainRadio.checked = true;
        }
        if (nameGroup) {
            nameGroup.style.display = 'none';
        }
    }
}

/**
 * 创建规则项HTML
 * @param {string} defaultType - 默认选择的绑定类型 ('main', 'process', 'thread')
 * @returns {string} HTML字符串
 */
function createProcessItemHtml(defaultType = 'main') {
    const uniqueId = generateId();

    // 根据默认类型设置选中状态
    const mainChecked = defaultType === 'main' ? 'checked' : '';
    const processChecked = defaultType === 'process' ? 'checked' : '';
    const threadChecked = defaultType === 'thread' ? 'checked' : '';

    return `
        <div class="process-item">
            <div class="form-row">
                <div class="form-group">
                    <label>绑定类型</label>
                    <div class="binding-type-group">
                        <label class="binding-type-option">
                            <input type="radio" name="binding-type-${uniqueId}" value="main" class="binding-type-radio" ${mainChecked}>
                            <span class="binding-type-label">
                                <i class="material-icons-round">layers</i>
                                主进程
                            </span>
                        </label>
                        <label class="binding-type-option">
                            <input type="radio" name="binding-type-${uniqueId}" value="process" class="binding-type-radio" ${processChecked}>
                            <span class="binding-type-label">
                                <i class="material-icons-round">select_all</i>
                                子进程
                            </span>
                        </label>
                        <label class="binding-type-option">
                            <input type="radio" name="binding-type-${uniqueId}" value="thread" class="binding-type-radio" ${threadChecked}>
                            <span class="binding-type-label">
                                <i class="material-icons-round">fiber_manual_record</i>
                                线程
                            </span>
                        </label>
                    </div>
                </div>
                <div class="form-group binding-name-group">
                    <label class="binding-name-label">名称</label>
                    <div style="position: relative;">
                        <input type="text" class="form-control binding-name" placeholder="">
                        <div class="autocomplete-dropdown"></div>
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>绑定核心</label>
                    <input type="text" class="form-control binding-cores" placeholder="例如: 0-3,5-7">
                    <span class="form-hint">单个核心(0)、连续范围(0-3)或组合(0-3,5-7)</span>
                </div>
                <button class="remove-btn" title="删除该规则">
                    <i class="material-icons-round">delete</i>
                </button>
            </div>
        </div>
    `;
}

/**
 * 绑定规则项移除按钮事件
 */
function bindRemoveProcessButtons() {
    document.querySelectorAll('.process-item .remove-btn').forEach(btn => {
        btn.removeEventListener('click', handleRemoveProcessItem);
        btn.addEventListener('click', handleRemoveProcessItem);
    });
}

/**
 * 处理移除规则项的点击事件
 */
function handleRemoveProcessItem() {
    const processItem = this.closest('.process-item');
    const processList = document.getElementById('process-list');

    if (!processList) return;

    // 如果是唯一的规则项，不允许删除
    if (processList.querySelectorAll('.process-item').length <= 1) {
        showToast('至少需要一个规则项', 'warning');
        return;
    }

    // 获取实际高度
    const actualHeight = processItem.offsetHeight;

    // 设置初始样式以准备动画
    processItem.style.height = actualHeight + 'px';
    processItem.style.overflow = 'hidden';

    // 添加过渡类，确保所有样式变化都有动画效果
    requestAnimationFrame(() => {
        processItem.classList.add('removing');
        processItem.style.opacity = '0';
        processItem.style.height = '0';
        processItem.style.margin = '0';
        processItem.style.padding = '0';
        processItem.style.border = 'none';

        // 监听过渡结束后移除元素
        processItem.addEventListener('transitionend', function handler(e) {
            // 只在高度变化完成时移除元素
            if (e.propertyName === 'height') {
                if (processList.contains(processItem)) {
                    processList.removeChild(processItem);
                }
                processItem.removeEventListener('transitionend', handler);
            }
        });
    });
}

/**
 * 绑定规则类型切换事件
 */
function bindBindingTypeEvents() {
    // 只绑定添加应用模态框中的单选框
    const addAppModal = document.getElementById('add-app-modal');
    if (!addAppModal) return;

    addAppModal.querySelectorAll('.binding-type-radio').forEach(radio => {
        // 移除之前的事件监听器（如果有的话）
        radio.removeEventListener('change', handleBindingTypeChange);

        // 初始设置占位符文本
        if (radio.checked) {
            updateBindingNamePlaceholder(radio);
        }

        // 监听变化
        radio.addEventListener('change', handleBindingTypeChange);
    });
}

/**
 * 处理绑定类型变化
 */
function handleBindingTypeChange() {
    if (this.checked) {
        updateBindingNamePlaceholder(this);
    }
}

/**
 * 更新绑定名称输入框的占位符
 * @param {HTMLInputElement} radioElement - 类型选择单选框
 */
function updateBindingNamePlaceholder(radioElement) {
    const type = radioElement.value;
    const processItem = radioElement.closest('.process-item');
    const nameGroup = processItem.querySelector('.binding-name-group');
    const nameInput = processItem.querySelector('.binding-name');
    const nameLabel = processItem.querySelector('.binding-name-label');

    if (type === 'main') {
        // 隐藏名称输入框组
        nameGroup.style.display = 'none';
        nameInput.value = ''; // 清空输入值
    } else if (type === 'process') {
        // 显示名称输入框组
        nameGroup.style.display = 'block';
        nameInput.placeholder = '例如: push';
        nameInput.disabled = false;
        nameLabel.textContent = '进程名称';
    } else if (type === 'thread') {
        // 显示名称输入框组
        nameGroup.style.display = 'block';
        nameInput.placeholder = '例如: RenderThread';
        nameInput.disabled = false;
        nameLabel.textContent = '线程名称';
    }
}

/**
 * 添加规则项
 */
function addProcessItem() {
    const processList = document.getElementById('process-list');
    if (!processList) return;

    // 后续添加的规则默认选择线程
    const template = document.createElement('template');
    template.innerHTML = createProcessItemHtml('thread').trim();
    const newItem = template.content.firstChild;

    // 设置初始样式为隐藏
    newItem.style.opacity = '0';
    newItem.style.maxHeight = '0';
    newItem.style.margin = '0';
    newItem.style.overflow = 'hidden';

    // 添加到容器
    processList.appendChild(newItem);

    // 获取实际高度
    const actualHeight = newItem.scrollHeight;

    // 添加出现动画类
    newItem.classList.add('appearing');

    // 动画显示
    requestAnimationFrame(() => {
        newItem.style.opacity = '1';
        newItem.style.maxHeight = actualHeight + 'px';
        newItem.style.margin = '';

        // 监听过渡结束后移除限制
        newItem.addEventListener('transitionend', function handler(e) {
            if (e.propertyName === 'max-height') {
                newItem.style.maxHeight = 'none';
                newItem.style.overflow = 'visible';
                newItem.classList.remove('appearing');
                newItem.removeEventListener('transitionend', handler);
            }
        });
    });

    // 绑定事件
    bindRemoveProcessButtons();

    // 只为新添加的项绑定绑定类型事件
    const newRadios = newItem.querySelectorAll('.binding-type-radio');
    newRadios.forEach(radio => {
        radio.removeEventListener('change', handleBindingTypeChange);

        // 初始设置占位符文本和显示状态
        if (radio.checked) {
            updateBindingNamePlaceholder(radio);
        }

        // 监听变化
        radio.addEventListener('change', handleBindingTypeChange);
    });

    // 滚动到新添加的项
    setTimeout(() => {
        newItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 50);
}

/**
 * 更新应用绑定列表
 * @param {string} searchText - 搜索文本
 */
function updateBindingsList(searchText = '') {
    const appListContainer = document.getElementById('app-list');
    const emptyState = document.getElementById('empty-state');

    if (!appListContainer) return;

    // 清空当前列表
    appListContainer.innerHTML = '';

    // 如果没有应用，显示空状态
    if (appBindings.length === 0) {
        if (emptyState) emptyState.classList.add('active');
        return;
    }

    // 隐藏空状态
    if (emptyState) emptyState.classList.remove('active');

    // 按包名对绑定进行分组
    const bindingsByPackage = {};
    for (const binding of appBindings) {
        if (!bindingsByPackage[binding.packageName]) {
            bindingsByPackage[binding.packageName] = [];
        }
        bindingsByPackage[binding.packageName].push(binding);
    }

    // 应用包名列表
    const packageNames = Object.keys(bindingsByPackage);

    // 按应用名称排序
    packageNames.sort((a, b) => {
        const nameA = appNames[a] || a;
        const nameB = appNames[b] || b;
        return nameA.localeCompare(nameB);
    });

    // 处理搜索
    const filteredPackages = searchText ?
        packageNames.filter(packageName => {
            const appName = (typeof appNames !== 'undefined' ? appNames[packageName] : '') || '';
            const bindings = bindingsByPackage[packageName];

            // 匹配应用名或包名
            if (appName.toLowerCase().includes(searchText) ||
                packageName.toLowerCase().includes(searchText)) {
                return true;
            }

            // 匹配进程名或线程名
            return bindings.some(binding =>
                (binding.processName && binding.processName.toLowerCase().includes(searchText)) ||
                (binding.threadName && binding.threadName.toLowerCase().includes(searchText))
            );
        }) :
        packageNames;

    // 如果搜索结果为空
    if (filteredPackages.length === 0) {
        appListContainer.innerHTML = `
            <div class="empty-search">
                <i class="material-icons-round">search_off</i>
                <p>没有找到匹配的应用</p>
            </div>
        `;
        return;
    }

    // 渲染每个应用卡片
    filteredPackages.forEach(packageName => {
        const card = createAppCard(packageName, bindingsByPackage[packageName], searchText);
        appListContainer.appendChild(card);
    });

    // 绑定卡片展开/折叠事件
    bindAppCardEvents();

    // 检查底部项是否可见
    setTimeout(() => {
        // 获取应用列表底部的位置
        const appFooter = document.querySelector('.app-footer');
        const appMain = document.querySelector('.app-main');
        if (appMain && appFooter && filteredPackages.length > 0) {
            const lastCard = appListContainer.querySelector('.app-card:last-child');
            if (lastCard) {
                // 获取底部工具栏的高度
                const footerHeight = appFooter.offsetHeight;
                // 添加额外的底部间距，确保最后一个卡片完全可见
                appListContainer.style.paddingBottom = `${footerHeight + 16}px`;
            }
        }
    }, 100);
}

/**
 * 显示确认对话框
 * @param {string} title - 标题
 * @param {string} message - 消息内容
 * @param {Function} onConfirm - 确认回调
 * @param {boolean} useBottomSheet - 是否使用底部弹出确认框（移动端）
 */
function showConfirmDialog(title, message, onConfirm, useBottomSheet = false) {
    // 检测是否为移动设备
    const isMobile = window.innerWidth <= 480;

    // 如果是移动设备且指定使用底部弹出框，则使用底部弹出确认框
    if (isMobile && useBottomSheet) {
        createBottomSheetConfirm({
            title: title,
            message: message,
            confirmText: '确定',
            cancelText: '取消',
            onConfirm: onConfirm,
            onCancel: () => {
                // 取消时不执行任何操作
            }
        });
    } else {
        // 使用常规确认对话框
        createConfirmDialog({
            title: title,
            message: message,
            confirmText: '确定',
            cancelText: '取消',
            onConfirm: onConfirm,
            onCancel: () => {
                // 取消时不执行任何操作
            }
        });
    }
}

/**
 * 隐藏确认对话框
 */
function hideConfirmDialog() {
    hideModal('confirm-dialog');
}





/**
 * 刷新绑定列表，重新加载配置文件和应用列表
 */
function refreshBindingsList() {
    // 显示加载动画
    const loadingOverlay = document.querySelector('.loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.classList.add('active');
    }

    // 重新加载配置文件和应用列表
    (async () => {
        const startTime = performance.now();

        try {
            // 如果loadConfig函数存在于app.js中，则调用该函数
            if (typeof loadConfig === 'function') {
                // 重新从系统读取配置文件（已经包含并行加载优化）
                await loadConfig();

                const endTime = performance.now();
                const loadTime = Math.round(endTime - startTime);
                showToast(`配置和应用列表已重新加载 (${loadTime}ms)`, 'success');
            } else {
                // 兼容情况：如果loadConfig不存在，则只刷新UI和应用列表
                const searchText = document.getElementById('search-input')?.value.trim() || '';
                updateBindingsList(searchText);

                // 刷新应用列表
                if (typeof loadAppList === 'function') {
                    await loadAppList();
                }

                const endTime = performance.now();
                const loadTime = Math.round(endTime - startTime);
                showToast(`列表已刷新 (${loadTime}ms)`, 'success');
            }
        } catch (error) {
            showToast('重新加载失败，请检查权限', 'error');
        } finally {
            // 关闭加载动画
            if (loadingOverlay) {
                loadingOverlay.classList.remove('active');
            }
        }
    })();
}

/**
 * 动态创建应用卡片
 * @param {string} packageName - 应用包名
 * @param {Array} bindings - 绑定规则数组
 * @param {string} searchText - 搜索文本，用于高亮匹配项
 * @returns {HTMLElement} 卡片元素
 */
function createAppCard(packageName, bindings, searchText = '') {
    // 创建卡片容器
    const card = document.createElement('div');
    card.className = 'card app-card';
    card.dataset.package = packageName;

    // 应用名称
    const appName = appNames[packageName] || packageName;

    // 创建卡片头部
    card.innerHTML = `
        <div class="app-card-header">
            <div class="app-card-title">
                <h3 class="app-name">${appName}</h3>
                <span class="app-package">${packageName}</span>
            </div>
            <div class="app-card-actions">
                <button class="app-action edit">
                    <i class="material-icons-round">edit</i>
                </button>
                <button class="app-action add">
                    <i class="material-icons-round">add</i>
                </button>
                <button class="app-action delete">
                    <i class="material-icons-round">delete</i>
                </button>
            </div>
            <div class="app-card-arrow"></div>
        </div>
        <div class="app-card-body">
            <div class="binding-list"></div>
        </div>
    `;

    // 处理应用名和包名过长的情况
    handleLongAppNames(card);

    // 创建绑定规则列表
    const bindingList = card.querySelector('.binding-list');
    if (bindingList && bindings.length > 0) {
        bindings.forEach(binding => {
            bindingList.appendChild(createBindingItem(binding, searchText));
        });
    }

    return card;
}

/**
 * 创建绑定规则项
 * @param {Object} binding - 绑定规则对象
 * @param {string} searchText - 搜索文本，用于高亮匹配项
 * @returns {HTMLElement} 绑定项元素
 */
function createBindingItem(binding, searchText = '') {
    const item = document.createElement('div');
    item.className = 'binding-item';
    item.dataset.id = binding.id;

    // 确定绑定类型
    let type = 'main';
    let targetName = '';

    if (binding.threadName) {
        type = 'thread';
        targetName = binding.threadName;
    } else if (binding.processName) {
        type = 'process';
        targetName = binding.processName.startsWith(':') ? binding.processName.substring(1) : binding.processName;
    }

    // 处理高亮显示
    let highlightedName = targetName;
    if (searchText && targetName && targetName.toLowerCase().includes(searchText.toLowerCase())) {
        const re = new RegExp(`(${escapeRegExp(searchText)})`, 'gi');
        highlightedName = targetName.replace(re, '<mark>$1</mark>');
    }

    // 添加启用/禁用状态类
    if (binding.enabled === false) {
        item.classList.add('disabled');
    }

    // 创建绑定项内容
    item.innerHTML = `
        ${getTypeTagHtml(type)}
        <div class="binding-info">
            <span class="binding-target">${highlightedName}</span>
            <span class="binding-cores">${binding.cores}</span>
            ${binding.enabled === false ? '<span class="binding-status disabled">已禁用</span>' : ''}
        </div>
        <div class="binding-actions">
            <button class="binding-action toggle" data-enabled="${binding.enabled !== false}">
                <i class="material-icons-round">${binding.enabled === false ? 'play_arrow' : 'pause'}</i>
            </button>
            <button class="binding-action edit">
                <i class="material-icons-round">edit</i>
            </button>
            <button class="binding-action delete">
                <i class="material-icons-round">delete</i>
            </button>
        </div>
    `;

    // 处理绑定名称过长的情况
    handleLongBindingNames(item);

    return item;
}

/**
 * 绑定应用卡片事件
 */
function bindAppCardEvents() {
    // 卡片展开/折叠
    document.querySelectorAll('.app-card-header').forEach(header => {
        header.addEventListener('click', function(e) {
            // 忽略点击操作按钮的情况
            if (e.target.closest('.app-action')) return;

            const card = this.closest('.app-card');
            toggleCardExpand(card);
        });
    });

    // 编辑应用名
    document.querySelectorAll('.app-action.edit').forEach(btn => {
        btn.addEventListener('click', function() {
            const card = this.closest('.app-card');
            const packageName = card.dataset.package;
            showEditNameModal(packageName);
        });
    });

    // 添加规则
    document.querySelectorAll('.app-action.add').forEach(btn => {
        btn.addEventListener('click', function() {
            const card = this.closest('.app-card');
            const packageName = card.dataset.package;
            showAddRuleModal(packageName);
        });
    });

    // 删除应用
    document.querySelectorAll('.app-action.delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const card = this.closest('.app-card');
            const packageName = card.dataset.package;
            const appName = appNames[packageName] || packageName;

            // 确认删除，处理长应用名
            const displayName = appName.length > 20 ? appName.substring(0, 17) + '...' : appName;
            showConfirmDialog(
                '删除应用',
                `确定要删除应用 "${appName}" 的所有规则吗？`,
                () => deleteAppBindings(packageName),
                true // 使用底部弹出确认框
            );
        });
    });

    // 切换绑定规则启用/禁用
    document.querySelectorAll('.binding-action.toggle').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.closest('.binding-item');
            const bindingId = item.dataset.id;
            toggleBinding(bindingId);
        });
    });

    // 编辑绑定规则
    document.querySelectorAll('.binding-action.edit').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.closest('.binding-item');
            const bindingId = item.dataset.id;
            showEditBindingModal(bindingId);
        });
    });

    // 删除绑定规则
    document.querySelectorAll('.binding-action.delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const item = this.closest('.binding-item');
            const bindingId = item.dataset.id;

            // 获取绑定信息
            const binding = appBindings.find(b => b.id === bindingId);
            if (!binding) return;

            // 构建显示名称
            let targetName = '';
            if (binding.threadName) {
                targetName = `线程 "${binding.threadName}"`;
            } else if (binding.processName) {
                targetName = `进程 "${binding.processName.startsWith(':') ? binding.processName.substring(1) : binding.processName}"`;
            } else {
                targetName = '主进程规则';
            }

            showConfirmDialog(
                '删除规则',
                `确定要删除${targetName}吗？`,
                () => deleteBinding(bindingId),
                true // 使用底部弹出确认框
            );
        });
    });
}

/**
 * 切换卡片展开/折叠状态
 * @param {HTMLElement} card - 卡片元素
 */
function toggleCardExpand(card) {
    if (!card) return;

    // 切换展开状态
    card.classList.toggle('expanded');
}

/**
 * 显示编辑应用名模态框
 * @param {string} packageName - 应用包名
 */
function showEditNameModal(packageName) {
    const modal = document.getElementById('edit-name-modal');
    if (!modal) return;

    const nameInput = document.getElementById('edit-app-name');
    const packageInput = document.getElementById('edit-package');

    if (nameInput) nameInput.value = appNames[packageName] || '';
    if (packageInput) packageInput.value = packageName;

    // 记录当前编辑的包名
    currentEditPackage = packageName;

    // 显示模态框
    showModal('edit-name-modal');

    // 重新初始化应用名称补全
    if (typeof setupAppNameInput === 'function') {
        setTimeout(() => {
            setupAppNameInput('#edit-app-name', '#edit-package');
        }, 50);
    }
}

/**
 * 显示添加规则模态框
 * @param {string} packageName - 应用包名
 */
function showAddRuleModal(packageName) {
    const modal = document.getElementById('add-rule-modal');
    if (!modal) return;

    // 设置应用信息
    const appNameElement = document.getElementById('rule-app-name');
    const packageElement = document.getElementById('rule-app-package');

    if (appNameElement) {
        appNameElement.textContent = (typeof appNames !== 'undefined' ? appNames[packageName] : '') || packageName;
    }
    if (packageElement) {
        packageElement.textContent = packageName;
    }

    // 重置规则列表
    resetRuleProcessList();

    // 显示模态框
    showModal('add-rule-modal');

    // 延迟重新绑定事件，确保DOM已更新
    setTimeout(() => {
        // 重新绑定绑定类型事件
        bindRuleBindingTypeEvents();
    }, 50);
}

/**
 * 重置添加规则模态框的规则列表
 */
function resetRuleProcessList() {
    const processList = document.getElementById('rule-process-list');
    if (!processList) return;

    // 清空现有规则
    processList.innerHTML = '';

    // 添加一个默认规则项（默认选择主进程）
    const template = document.createElement('template');
    template.innerHTML = createProcessItemHtml('main').trim();
    const newItem = template.content.cloneNode(true);
    processList.appendChild(newItem);

    // 重新绑定移除按钮事件
    bindRuleRemoveProcessButtons();

    // 为新添加的规则项设置初始状态（主进程选中，名称输入框隐藏）
    const firstItem = processList.querySelector('.process-item');
    if (firstItem) {
        const mainRadio = firstItem.querySelector('input[value="main"]');
        const nameGroup = firstItem.querySelector('.binding-name-group');

        if (mainRadio) {
            mainRadio.checked = true;
        }
        if (nameGroup) {
            nameGroup.style.display = 'none';
        }
    }
}

/**
 * 绑定添加规则模态框中的绑定类型事件
 */
function bindRuleBindingTypeEvents() {
    const ruleModal = document.getElementById('add-rule-modal');
    if (!ruleModal) return;

    ruleModal.querySelectorAll('.binding-type-radio').forEach(radio => {
        radio.removeEventListener('change', handleBindingTypeChange);

        // 初始设置占位符文本
        if (radio.checked) {
            updateBindingNamePlaceholder(radio);
        }

        // 监听变化
        radio.addEventListener('change', handleBindingTypeChange);
    });
}

/**
 * 绑定添加规则模态框中的移除按钮事件
 */
function bindRuleRemoveProcessButtons() {
    const ruleModal = document.getElementById('add-rule-modal');
    if (!ruleModal) return;

    ruleModal.querySelectorAll('.remove-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const processItem = this.closest('.process-item');
            const processList = processItem.parentNode;

            // 如果只有一个规则项，不允许删除
            if (processList.children.length <= 1) {
                showToast('至少需要保留一条规则', 'warning');
                return;
            }

            // 添加移除动画
            processItem.style.transition = 'all 0.3s ease';
            processItem.style.opacity = '0';
            processItem.style.maxHeight = '0';
            processItem.style.margin = '0';

            setTimeout(() => {
                processItem.remove();
            }, 300);
        });
    });
}

/**
 * 添加规则项到添加规则模态框
 */
function addRuleProcessItem() {
    const processList = document.getElementById('rule-process-list');
    if (!processList) return;

    // 后续添加的规则默认选择线程
    const template = document.createElement('template');
    template.innerHTML = createProcessItemHtml('thread').trim();
    const newItem = template.content.firstChild;

    // 设置初始样式为隐藏
    newItem.style.opacity = '0';
    newItem.style.maxHeight = '0';
    newItem.style.margin = '0';
    newItem.style.overflow = 'hidden';

    // 添加到容器
    processList.appendChild(newItem);

    // 获取实际高度
    const actualHeight = newItem.scrollHeight;

    // 添加出现动画类
    newItem.classList.add('appearing');

    // 触发动画
    requestAnimationFrame(() => {
        newItem.style.transition = 'all 0.3s ease';
        newItem.style.opacity = '1';
        newItem.style.maxHeight = actualHeight + 'px';
        newItem.style.margin = '';

        // 动画完成后清理样式
        setTimeout(() => {
            newItem.style.maxHeight = '';
            newItem.style.transition = '';
            newItem.classList.remove('appearing');
        }, 300);
    });

    // 绑定事件
    bindRuleRemoveProcessButtons();

    // 只为新添加的项绑定绑定类型事件
    const newRadios = newItem.querySelectorAll('.binding-type-radio');
    newRadios.forEach(radio => {
        radio.removeEventListener('change', handleBindingTypeChange);

        // 初始设置占位符文本和显示状态
        if (radio.checked) {
            updateBindingNamePlaceholder(radio);
        }

        // 监听变化
        radio.addEventListener('change', handleBindingTypeChange);
    });

    // 滚动到新添加的项
    setTimeout(() => {
        newItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 350);
}

/**
 * 初始化滚动隐藏底部工具栏功能
 */
function initScrollHideToolbar() {
    const appMain = document.querySelector('.app-main');
    const appFooter = document.querySelector('.app-footer');

    if (!appMain || !appFooter) return;

    let lastScrollTop = 0;
    let scrollTimer = null;
    let isScrolling = false;

    // 获取底部工具栏高度
    const footerHeight = appFooter.offsetHeight;

    // 设置底部工具栏显示隐藏状态
    const showFooter = () => {
        appFooter.classList.remove('hidden');
        // 恢复内容区域底部内边距
        appMain.style.paddingBottom = `calc(${footerHeight}px + var(--space-xl))`;
    };

    const hideFooter = () => {
        appFooter.classList.add('hidden');
        // 减小内容区域底部内边距，但仍保留足够空间
        appMain.style.paddingBottom = `calc(var(--space-md) + var(--space-lg))`;
    };

    // 滚动处理函数
    const handleScroll = () => {
        isScrolling = true;

        const currentScrollTop = appMain.scrollTop;

        // 向下滚动超过20px时，隐藏底部工具栏
        if (currentScrollTop > lastScrollTop && currentScrollTop > 20) {
            hideFooter();
        }
        // 向上滚动时，显示底部工具栏
        else if (currentScrollTop < lastScrollTop) {
            showFooter();
        }

        lastScrollTop = currentScrollTop;

        // 清除之前的定时器
        if (scrollTimer) {
            clearTimeout(scrollTimer);
        }

        // 设置新的定时器，滚动停止一段时间后显示工具栏
        scrollTimer = setTimeout(() => {
            showFooter();
            isScrolling = false;
        }, 500);
    };

    // 添加滚动事件监听
    appMain.addEventListener('scroll', debounce(handleScroll, 50));

    // 触摸事件处理
    let touchStartY = 0;
    let touchEndY = 0;

    appMain.addEventListener('touchstart', (e) => {
        touchStartY = e.touches[0].clientY;
    }, { passive: true });

    appMain.addEventListener('touchmove', (e) => {
        touchEndY = e.touches[0].clientY;
        const touchDiff = touchEndY - touchStartY;

        // 下拉超过20px显示工具栏
        if (touchDiff > 20) {
            showFooter();
        }
        // 上拉超过20px隐藏工具栏
        else if (touchDiff < -20) {
            hideFooter();
        }
    }, { passive: true });

    appMain.addEventListener('touchend', () => {
        // 重置触摸位置
        touchStartY = 0;
        touchEndY = 0;

        // 如果没有在滚动，则在触摸结束后显示工具栏
        if (!isScrolling) {
            setTimeout(() => {
                showFooter();
            }, 200);
        }
    });
}

/**
 * 显示API消息通知
 * @param {string} type - 消息类型: 'warning' 或 'error'
 * @param {string} message - 消息内容
 */
function showApiMessage(type, message) {
    // 先移除可能存在的旧消息
    removeApiMessages();

    const appMain = document.querySelector('.app-main');
    if (!appMain) return;

    // 创建消息元素
    const messageEl = document.createElement('div');
    messageEl.className = `kernel-message ${type}`;

    // 设置图标
    const icon = type === 'error' ? 'error' : 'warning';

    // 创建消息内容
    messageEl.innerHTML = `
        <i class="material-icons-round">${icon}</i>
        <span>${message}</span>
    `;

    // 插入到搜索栏之前
    const searchSection = appMain.querySelector('.search-section');
    if (searchSection) {
        appMain.insertBefore(messageEl, searchSection);
    } else {
        appMain.prepend(messageEl);
    }
}

/**
 * 移除所有API消息通知
 */
function removeApiMessages() {
    document.querySelectorAll('.kernel-message').forEach(msg => {
        msg.remove();
    });
}

// 确保底部项目可见
function ensureBottomItemsVisible() {
    const appMain = document.querySelector('.app-main');
    const appList = document.getElementById('app-list');

    if (!appMain || !appList) return;

    // 监听列表更新
    const observer = new MutationObserver(() => {
        // 获取列表中最后一个应用卡片
        const lastCard = appList.querySelector('.app-card:last-child');
        if (lastCard) {
            // 确保底部有足够空间
            const appFooter = document.querySelector('.app-footer');
            if (appFooter) {
                const footerHeight = appFooter.offsetHeight;
                // 计算可能的遮挡
                const mainRect = appMain.getBoundingClientRect();
                const cardRect = lastCard.getBoundingClientRect();
                const bottomSpace = mainRect.bottom - cardRect.bottom;

                if (bottomSpace < footerHeight + 24) {
                    // 如果空间不足，添加额外填充
                    appList.style.paddingBottom = `${footerHeight + 32}px`;
                }
            }
        }
    });

    // 观察列表变化
    observer.observe(appList, { childList: true, subtree: true });

    // 初始检查
    setTimeout(() => {
        const lastCard = appList.querySelector('.app-card:last-child');
        if (lastCard) {
            const appFooter = document.querySelector('.app-footer');
            if (appFooter) {
                const footerHeight = appFooter.offsetHeight;
                appList.style.paddingBottom = `${footerHeight + 16}px`;
            }
        }
    }, 500);
}

// 显示批量操作模态框
function showBatchModal() {
    // 生成应用列表
    updateBatchAppList();

    // 显示模态框
    showModal('batch-modal');
}

/**
 * 显示应用范围设置模态框
 */
function showAppScopeModal() {
    // 获取当前设置
    const currentScope = getAppScope();

    // 设置当前选中的选项
    const radioButtons = document.querySelectorAll('input[name="app-scope"]');
    radioButtons.forEach(radio => {
        radio.checked = radio.value === currentScope;
    });

    // 显示模态框
    showModal('app-scope-modal');
}

/**
 * 确认应用范围设置
 */
async function confirmAppScope() {
    const selectedRadio = document.querySelector('input[name="app-scope"]:checked');
    if (!selectedRadio) {
        showToast('请选择应用范围', 'warning');
        return;
    }

    const newScope = selectedRadio.value;
    const oldScope = getAppScope();

    // 如果设置没有变化，直接关闭
    if (newScope === oldScope) {
        hideModal('app-scope-modal');
        return;
    }

    // 保存新设置
    setAppScope(newScope);

    // 关闭模态框
    hideModal('app-scope-modal');

    // 显示加载提示
    showToast(`已切换到${getAppScopeName()}，正在重新加载...`, 'info');

    // 重新加载应用列表
    try {
        if (typeof loadAppList === 'function') {
            await loadAppList();
        }
    } catch (error) {
        showToast('重新加载应用列表失败', 'error');
    }
}

// 更新批量操作应用列表
function updateBatchAppList() {
    const batchAppList = document.getElementById('batch-app-list');
    if (!batchAppList) return;

    // 清空列表
    batchAppList.innerHTML = '';

    // 按包名对绑定进行分组
    const bindingsByPackage = {};
    for (const binding of appBindings) {
        if (!bindingsByPackage[binding.packageName]) {
            bindingsByPackage[binding.packageName] = [];
        }
        bindingsByPackage[binding.packageName].push(binding);
    }

    const packageNames = Object.keys(bindingsByPackage);

    // 如果没有应用
    if (packageNames.length === 0) {
        batchAppList.innerHTML = `
            <div class="batch-empty">
                <i class="material-icons-round">apps</i>
                <h3>暂无应用</h3>
                <p>请先添加一些应用规则</p>
            </div>
        `;
        return;
    }

    // 按应用名称排序
    packageNames.sort((a, b) => {
        const nameA = appNames[a] || a;
        const nameB = appNames[b] || b;
        return nameA.localeCompare(nameB);
    });

    // 生成应用项
    packageNames.forEach(packageName => {
        const bindings = bindingsByPackage[packageName];
        const appName = appNames[packageName] || packageName;

        // 检查应用的启用状态
        const enabledCount = bindings.filter(b => b.enabled !== false).length;
        const totalCount = bindings.length;
        const isFullyEnabled = enabledCount === totalCount;
        const isFullyDisabled = enabledCount === 0;

        const appItem = document.createElement('div');
        appItem.className = 'batch-app-item';
        appItem.innerHTML = `
            <input type="checkbox" class="batch-app-checkbox" data-package="${packageName}">
            <div class="batch-app-info">
                <div class="batch-app-name">${appName}</div>
                <div class="batch-app-package">${packageName}</div>
            </div>
            <div class="batch-app-status">
                <span class="batch-rule-count">${totalCount} 条规则</span>
                <span class="batch-status-badge ${isFullyEnabled ? 'enabled' : (isFullyDisabled ? 'disabled' : 'mixed')}">
                    ${isFullyEnabled ? '已启用' : (isFullyDisabled ? '已禁用' : '部分启用')}
                </span>
            </div>
        `;

        batchAppList.appendChild(appItem);
    });

    // 绑定复选框事件
    bindBatchCheckboxEvents();

    // 更新按钮状态
    updateBatchButtonStates();
}

// 绑定批量操作复选框事件
function bindBatchCheckboxEvents() {
    const checkboxes = document.querySelectorAll('.batch-app-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateBatchButtonStates);
    });
}

// 更新批量操作按钮状态
function updateBatchButtonStates() {
    const checkboxes = document.querySelectorAll('.batch-app-checkbox');
    const selectedCheckboxes = document.querySelectorAll('.batch-app-checkbox:checked');

    const selectedCount = selectedCheckboxes.length;
    const totalCount = checkboxes.length;

    // 更新选择计数
    const countElement = document.getElementById('batch-selected-count');
    if (countElement) {
        countElement.textContent = `已选择 ${selectedCount} 个应用`;
    }

    // 更新按钮状态
    const enableBtn = document.getElementById('batch-enable-btn');
    const disableBtn = document.getElementById('batch-disable-btn');

    if (enableBtn) {
        enableBtn.disabled = selectedCount === 0;
    }
    if (disableBtn) {
        disableBtn.disabled = selectedCount === 0;
    }

    // 检查选中的应用状态，决定按钮可用性
    if (selectedCount > 0) {
        let hasDisabled = false;
        let hasEnabled = false;

        selectedCheckboxes.forEach(checkbox => {
            const packageName = checkbox.dataset.package;
            const bindings = appBindings.filter(b => b.packageName === packageName);
            const enabledCount = bindings.filter(b => b.enabled !== false).length;

            if (enabledCount === 0) {
                hasDisabled = true;
            } else if (enabledCount === bindings.length) {
                hasEnabled = true;
            } else {
                hasDisabled = true;
                hasEnabled = true;
            }
        });

        // 如果所有选中的应用都已启用，禁用启用按钮
        if (enableBtn) {
            enableBtn.disabled = !hasDisabled;
        }

        // 如果所有选中的应用都已禁用，禁用禁用按钮
        if (disableBtn) {
            disableBtn.disabled = !hasEnabled;
        }
    }
}

// 全选应用
function selectAllApps() {
    const checkboxes = document.querySelectorAll('.batch-app-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = true;
    });
    updateBatchButtonStates();
}

// 取消全选
function selectNoneApps() {
    const checkboxes = document.querySelectorAll('.batch-app-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
    });
    updateBatchButtonStates();
}

// 批量启用应用
async function batchEnableApps() {
    const selectedCheckboxes = document.querySelectorAll('.batch-app-checkbox:checked');

    if (selectedCheckboxes.length === 0) {
        showToast('请先选择要启用的应用', 'warning');
        return;
    }

    let changedCount = 0;

    selectedCheckboxes.forEach(checkbox => {
        const packageName = checkbox.dataset.package;
        const bindings = appBindings.filter(b => b.packageName === packageName);

        bindings.forEach(binding => {
            if (binding.enabled === false) {
                binding.enabled = true;
                changedCount++;
            }
        });
    });

    if (changedCount > 0) {
        // 实时保存配置
        await saveConfig();

        // 更新UI
        updateBindingsList();
        updateBatchAppList();

        showToast(`已启用 ${changedCount} 条规则`, 'success');
    } else {
        showToast('选中的应用规则已全部启用', 'info');
    }
}

// 批量禁用应用
async function batchDisableApps() {
    const selectedCheckboxes = document.querySelectorAll('.batch-app-checkbox:checked');

    if (selectedCheckboxes.length === 0) {
        showToast('请先选择要禁用的应用', 'warning');
        return;
    }

    let changedCount = 0;

    selectedCheckboxes.forEach(checkbox => {
        const packageName = checkbox.dataset.package;
        const bindings = appBindings.filter(b => b.packageName === packageName);

        bindings.forEach(binding => {
            if (binding.enabled !== false) {
                binding.enabled = false;
                changedCount++;
            }
        });
    });

    if (changedCount > 0) {
        // 实时保存配置
        await saveConfig();

        // 更新UI
        updateBindingsList();
        updateBatchAppList();

        showToast(`已禁用 ${changedCount} 条规则`, 'success');
    } else {
        showToast('选中的应用规则已全部禁用', 'info');
    }
}

// 切换单个绑定规则的启用/禁用状态
async function toggleBinding(bindingId) {
    const binding = appBindings.find(b => b.id === bindingId);
    if (!binding) return;

    // 切换状态
    binding.enabled = binding.enabled === false ? true : false;

    // 实时保存配置
    await saveConfig();

    // 更新UI
    updateBindingsList();

    // 显示提示
    const status = binding.enabled === false ? '禁用' : '启用';
    showToast(`已${status}规则`, 'success');
}