// 主应用逻辑

// 全局状态
let appBindings = [];
let appNames = {};
let currentEditPackage = "";
let ksuApi = null;
let actionRunning = false;

// 页面初始化
document.addEventListener('DOMContentLoaded', async () => {

    try {
        initTheme();
        initUI();
        await initKernelSUApi();
        await loadConfig();
    } catch (error) {
        showToast('初始化失败，请检查权限或刷新页面', 'error');
    }
});

// 初始化KernelSU API
async function initKernelSUApi() {
    try {
        // 兼容不同的API引用方式
        if (typeof window.ksuApi !== 'undefined') {
            ksuApi = window.ksuApi;
        } else if (typeof window.ksu !== 'undefined') {
            ksuApi = window.ksu;
        }

        if (ksuApi) {
            // 验证API权限
            try {
                const result = await execCommand("whoami");
                if (result && result.trim() === "root") {
                    console.log("KernelSU API已初始化，Root权限已获取");
                    showToast("Root权限已确认", "success");
                } else {
                    console.warn("未能获取root权限，请检查KernelSU设置");
                    showToast("未能获取root权限，请检查KernelSU设置", "warning");
                }
            } catch (error) {
                console.error("验证Root权限失败:", error);
                showToast("无法验证Root权限，部分功能可能受限", "warning");
            }
        } else {
            // API不可用时的处理
            console.warn("KernelSU API不可用");
            showToast("KernelSU API不可用，部分功能可能受限", "warning");
        }
    } catch (error) {
        console.error("初始化KernelSU API失败:", error);
        showToast("初始化KernelSU API失败", "error");
    }
}

/**
 * 加载配置文件
 */
async function loadConfig() {
    try {
        // 并行执行配置文件读取和应用列表获取
        const [configResult, appListResult] = await Promise.allSettled([
            loadConfigFile(),
            loadAppList()
        ]);

        // 处理配置文件结果
        if (configResult.status === 'fulfilled' && configResult.value) {
            parseConfig(configResult.value);
            showToast('配置已加载', 'success');
        } else {
            showToast('配置文件不存在，将创建默认配置', 'info');
            createDefaultConfig();
        }

        // 更新UI
        updateBindingsList();

        // 更新智能建议列表
        if (typeof updateSuggestions === 'function') {
            updateSuggestions();
        }

        // 处理应用列表结果
        if (appListResult.status === 'fulfilled') {
            // loadAppList 内部已经处理了成功和失败的提示
        } else {
            // 应用列表加载失败的处理已在 loadAppList 中完成
        }

    } catch (error) {
        showToast('加载配置失败，将使用默认配置', 'error');
        createDefaultConfig();

        // 即使配置加载失败，也尝试获取应用列表
        try {
            await loadAppList();
        } catch (appError) {
            // 应用列表加载失败的处理已在 loadAppList 中完成
        }
    }
}

/**
 * 加载配置文件内容
 * @returns {Promise<string|null>} 配置文件内容或null
 */
async function loadConfigFile() {
    try {
        // 合并检查文件存在性和读取操作
        const result = await execCommand(`
            if [ -f ${CONFIG.CONFIG_FILE_PATH} ]; then
                cat ${CONFIG.CONFIG_FILE_PATH}
            else
                echo "FILE_NOT_EXISTS"
            fi
        `);

        if (result.trim() === 'FILE_NOT_EXISTS') {
            return null;
        }

        return result;
    } catch (error) {
        throw error;
    }
}

/**
 * 加载应用列表
 */
async function loadAppList() {
    const startTime = performance.now();

    try {
        const success = await fetchAppList();
        const endTime = performance.now();
        const loadTime = Math.round(endTime - startTime);

        if (success) {
            const appCount = getAllAppNames().length;
            showToast(`已加载 ${appCount} 个应用信息 (${loadTime}ms)`, 'success');
        } else {
            // 如果工具无法运行，清空应用名称映射
            appNameToPackageMap.clear();
            showToast('应用名称工具不可用，请手动输入包名', 'warning');
        }
    } catch (error) {
        // 出错时也清空应用名称映射
        appNameToPackageMap.clear();
        showToast('获取应用列表失败，请手动输入包名', 'warning');
    }
}

/**
 * 创建默认配置
 */
function createDefaultConfig() {
    // 设置默认值
    appBindings = [];
    appNames = {};

    // 更新UI
    updateBindingsList();
}

/**
 * 解析配置文件
 * @param {string} configText - 配置文件内容
 */
function parseConfig(configText) {
    // 清空现有绑定和应用名
    appBindings = [];
    appNames = {};

    // 按行解析
    const lines = configText.split('\n');
    let currentComment = null;
    let currentAppName = null;
    let currentPackageName = null;

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();

        // 跳过空行
        if (!line) continue;

        // 处理注释行
        if (line.startsWith('#')) {
            const comment = line.substring(1).trim();

            // 如果下一行包含等号且不是核心组配置，视为应用名
            if (i + 1 < lines.length) {
                const nextLine = lines[i + 1].trim();
                if (nextLine && nextLine.includes('=') && !isCoreSetting(nextLine.split('=')[0].trim())) {
                    const packageName = nextLine.split('=')[0].trim().split(/[:{\[]/)[0].trim();
                    currentAppName = comment;
                    appNames[packageName] = currentAppName;
                    continue;
                }
            }

            // 普通注释
            currentComment = comment;
            continue;
        }

        // 检查是否包含等号（绑定规则）
        if (line.includes('=')) {
            const parts = line.split('=');
            const target = parts[0].trim();
            const cores = parts[1].trim();

            // 跳过核心组配置
            if (isCoreSetting(target)) {
                continue;
            }

            // 解析标准绑定规则
            const binding = parseBindingRule(target, cores, currentComment);
            if (binding) {
                binding.enabled = true; // 未注释的规则默认启用
                appBindings.push(binding);
            }

            // 每次处理完一条规则后重置注释
            currentComment = null;
        }
        // 检查是否是被注释的绑定规则
        else if (line.startsWith('#') && line.includes('=')) {
            const uncommentedLine = line.substring(1).trim();
            if (uncommentedLine.includes('=')) {
                const parts = uncommentedLine.split('=');
                const target = parts[0].trim();
                const cores = parts[1].trim();

                // 跳过核心组配置
                if (isCoreSetting(target)) {
                    continue;
                }

                // 解析被注释的绑定规则
                const binding = parseBindingRule(target, cores, null);
                if (binding) {
                    binding.enabled = false; // 被注释的规则为禁用状态
                    appBindings.push(binding);
                }
            }
        }
    }
}

/**
 * 检查是否为核心组设置
 * @param {string} target - 目标字符串
 * @returns {boolean} 是否为核心组设置
 */
function isCoreSetting(target) {
    return target === 'small_cores' || target === '小核' ||
           target === 'medium_cores' || target === '中核' ||
           target === 'big_cores' || target === '大核' ||
           target === 'super_cores' || target === '超核';
}

/**
 * 解析绑定规则
 * @param {string} target - 目标字符串，例如 "com.example.app"、"com.example.app:process" 或 "com.example.app{Thread}"
 * @param {string} cores - CPU核心范围
 * @param {string} comment - 注释
 * @returns {Object|null} 绑定规则对象
 */
function parseBindingRule(target, cores, comment) {
    let packageName = target;
    let processName = '';
    let threadName = '';

    // 检查是否包含进程名（com.example.app:process）
    if (target.includes(':') && !target.includes('{')) {
        const parts = target.split(':');
        packageName = parts[0];
        processName = ':' + parts[1];
    }
    // 检查是否包含线程名（com.example.app{Thread}）
    else if (target.includes('{') && target.includes('}')) {
        const packagePart = target.split('{')[0];
        const threadPart = target.substring(target.indexOf('{') + 1, target.indexOf('}'));
        packageName = packagePart;
        threadName = threadPart;
    }

    return {
        packageName: packageName,
        processName: processName,
        threadName: threadName,
        cores: cores,
        comment: comment || '',
        id: generateId()
    };
}

/**
 * 生成配置文件内容
 * @returns {string} 配置文件内容
 */
function generateConfigContent() {
    let content = `# CPU亲和性设置配置文件
# 支持格式:
# 主进程: com.example.app=0-3
# 子进程: com.example.app:processName=0-1
# 线程:   com.example.app{threadName}=2-4
# 核心范围: 单个(0) | 连续(0-3) | 组合(0-1,5-7)

`;

    // 按包名对绑定进行分组
    const bindingsByPackage = {};

    for (const binding of appBindings) {
        if (!bindingsByPackage[binding.packageName]) {
            bindingsByPackage[binding.packageName] = [];
        }
        bindingsByPackage[binding.packageName].push(binding);
    }

    // 为每个应用生成配置
    for (const packageName in bindingsByPackage) {
        const appBindingRules = bindingsByPackage[packageName];

        // 添加应用名称作为注释
        if (appNames[packageName]) {
            content += `\n# ${appNames[packageName]}\n`;
        } else {
            content += `\n`;
        }

        // 添加绑定规则
        for (const binding of appBindingRules) {
            let target = binding.packageName;

            if (binding.processName) {
                target += binding.processName;
            } else if (binding.threadName) {
                target += `{${binding.threadName}}`;
            }

            // 如果规则被禁用，添加注释符号
            const prefix = binding.enabled === false ? '#' : '';
            content += `${prefix}${target}=${binding.cores}\n`;
        }
    }

    return content;
}

/**
 * 保存配置
 */
async function saveConfig() {
    if (actionRunning) {
        showToast('操作正在进行中，请稍后再试', 'info');
        return;
    }

    actionRunning = true;
    showLoading();

    try {
        // 生成配置内容
        const configContent = generateConfigContent();

        // 使用try/catch包装，确保编码错误不会导致整个操作失败
        try {
            // 使用base64编码避免转义问题
            const base64Content = btoa(unescape(encodeURIComponent(configContent)));
            await execCommand(`echo "${base64Content}" | base64 -d > ${CONFIG.CONFIG_FILE_PATH}`);
        } catch (encodeError) {
            console.error("编码配置失败，尝试直接写入:", encodeError);
            // 备选方案：尝试直接写入
            await execCommand(`cat > ${CONFIG.CONFIG_FILE_PATH} << 'EOT'\n${configContent}\nEOT`);
        }

        showToast('配置已保存', 'success');
    } catch (error) {
        console.error('保存配置失败:', error);
        showToast('保存配置失败，请检查权限', 'error');
    } finally {
        hideLoading();
        actionRunning = false;
    }
}

/**
 * 添加新应用
 */
function addNewApp() {
    // 获取表单数据
    const nameInput = document.getElementById('new-app-name');
    const packageInput = document.getElementById('new-app-package');

    if (!packageInput || !packageInput.value.trim()) {
        showToast('请输入应用包名', 'warning');
        return;
    }

    const packageName = packageInput.value.trim();
    const appName = nameInput.value.trim();

    // 保存应用名称
    if (appName) {
        appNames[packageName] = appName;
    }

    // 获取所有规则
    const processItems = document.querySelectorAll('.process-item');
    let hasValidRule = false;

    // 检查至少有一条有效规则
    processItems.forEach(item => {
        const typeRadio = item.querySelector('.binding-type-radio:checked');
        const coresInput = item.querySelector('.binding-cores');

        if (typeRadio && coresInput && coresInput.value.trim()) {
            hasValidRule = true;
        }
    });

    if (!hasValidRule) {
        showToast('请至少添加一条有效规则', 'warning');
        return;
    }

    // 处理每条规则
    processItems.forEach(item => {
        const typeRadio = item.querySelector('.binding-type-radio:checked');
        const nameInput = item.querySelector('.binding-name');
        const coresInput = item.querySelector('.binding-cores');

        if (!typeRadio || !coresInput || !coresInput.value.trim()) {
            return; // 跳过无效规则
        }

        const type = typeRadio.value;
        const name = nameInput.value.trim();
        const cores = coresInput.value.trim();

        // 验证核心格式
        if (!validateCoreInput(cores)) {
            showToast('核心格式无效，请检查', 'error');
            return;
        }

        // 创建绑定规则
        let processName = '';
        let threadName = '';

        if (type === 'process') {
            processName = name ? (name.startsWith(':') ? name : ':' + name) : '';
        } else if (type === 'thread') {
            threadName = name;
        }

        // 跳过无效的子进程或线程
        if ((type === 'process' && !processName) || (type === 'thread' && !threadName)) {
            showToast('请输入进程/线程名称', 'warning');
            return;
        }

        // 添加到绑定列表
        appBindings.push({
            packageName: packageName,
            processName: processName,
            threadName: threadName,
            cores: cores,
            comment: '',
            enabled: true, // 默认启用
            id: generateId()
        });
    });

    // 更新UI
    updateBindingsList();

    // 更新智能建议列表
    if (typeof updateSuggestions === 'function') {
        updateSuggestions();
    }

    // 隐藏模态框
    hideModal('add-app-modal');

    // 显示提示
    showToast('应用已添加', 'success');

    // 如果开启了自动保存，则保存配置
    if (CONFIG.AUTO_SAVE) {
        saveConfig();
    }
}

/**
 * 删除应用的所有绑定
 * @param {string} packageName - 应用包名
 */
function deleteAppBindings(packageName) {
    const appNameToShow = appNames[packageName] || packageName;

    // 删除绑定
    appBindings = appBindings.filter(binding => binding.packageName !== packageName);

    // 更新UI
    updateBindingsList();

    // 更新智能建议列表
    if (typeof updateSuggestions === 'function') {
        updateSuggestions();
    }

    // 如果开启了自动保存，则保存配置
    if (CONFIG.AUTO_SAVE) {
        saveConfig();
    }

    // 显示删除成功提示，处理长应用名
    let toastMessage = '';
    if (appNameToShow.length > 20) {
        // 对长应用名进行截断
        toastMessage = `已删除应用 "${appNameToShow.substring(0, 17)}..." 的所有绑定规则`;
    } else {
        toastMessage = `已删除应用 "${appNameToShow}" 的所有绑定规则`;
    }
    showToast(toastMessage, 'success');
}

/**
 * 删除单条绑定规则
 * @param {string} id - 绑定ID
 */
function deleteBinding(id) {
    // 查找并删除绑定
    const index = appBindings.findIndex(binding => binding.id === id);

    if (index !== -1) {
        appBindings.splice(index, 1);

        // 更新UI
        updateBindingsList();

        // 更新智能建议列表
        if (typeof updateSuggestions === 'function') {
            updateSuggestions();
        }

        // 如果开启了自动保存，则保存配置
        if (CONFIG.AUTO_SAVE) {
            saveConfig();
        }

        showToast('规则已删除', 'success');
    }
}

/**
 * 显示编辑绑定模态框
 * @param {string} bindingId - 绑定ID
 */
function showEditBindingModal(bindingId) {
    const binding = appBindings.find(b => b.id === bindingId);
    if (!binding) return;

    // 填充表单
    const packageInput = document.getElementById('edit-binding-package');
    const processInput = document.getElementById('edit-binding-process');
    const threadInput = document.getElementById('edit-binding-thread');
    const coresInput = document.getElementById('edit-binding-cores');
    const idInput = document.getElementById('edit-binding-id');

    if (packageInput) packageInput.value = binding.packageName;

    // 设置绑定类型
    let type = 'main';
    if (binding.threadName) {
        type = 'thread';
        if (threadInput) threadInput.value = binding.threadName;
    } else if (binding.processName) {
        type = 'process';
        if (processInput) processInput.value = binding.processName.startsWith(':') ?
            binding.processName.substring(1) : binding.processName;
    }

    // 设置单选框状态
    const typeRadio = document.getElementById(`edit-type-${type}`);
    if (typeRadio) typeRadio.checked = true;

    if (coresInput) coresInput.value = binding.cores;
    if (idInput) idInput.value = binding.id;

    // 切换表单字段可见性
    toggleBindingTypeFields();

    // 显示模态框
    showModal('edit-binding-modal');
}

/**
 * 根据绑定类型切换表单字段可见性
 */
function toggleBindingTypeFields() {
    const typeRadio = document.querySelector('input[name="edit-binding-type"]:checked');
    const processGroup = document.getElementById('edit-binding-process-group');
    const threadGroup = document.getElementById('edit-binding-thread-group');

    if (!typeRadio || !processGroup || !threadGroup) return;

    const type = typeRadio.value;

    // 隐藏所有字段
    processGroup.style.display = 'none';
    threadGroup.style.display = 'none';

    // 根据类型显示相应字段
    if (type === 'process') {
        processGroup.style.display = 'block';
    } else if (type === 'thread') {
        threadGroup.style.display = 'block';
    }
}

/**
 * 保存绑定修改
 */
function saveBindingChanges() {
    // 获取表单数据
    const packageInput = document.getElementById('edit-binding-package');
    const typeRadio = document.querySelector('input[name="edit-binding-type"]:checked');
    const processInput = document.getElementById('edit-binding-process');
    const threadInput = document.getElementById('edit-binding-thread');
    const coresInput = document.getElementById('edit-binding-cores');
    const idInput = document.getElementById('edit-binding-id');

    if (!packageInput || !typeRadio || !coresInput || !idInput) return;

    const packageName = packageInput.value.trim();
    const type = typeRadio.value;
    const cores = coresInput.value.trim();
    const id = idInput.value;

    // 验证数据
    if (!packageName) {
        showToast('包名不能为空', 'warning');
        return;
    }

    if (!cores) {
        showToast('请指定CPU核心范围', 'warning');
        return;
    }

    if (!validateCoreInput(cores)) {
        showToast('核心格式无效，请检查', 'error');
        return;
    }

    // 查找并更新绑定
    const index = appBindings.findIndex(binding => binding.id === id);

    if (index !== -1) {
        let processName = '';
        let threadName = '';

        if (type === 'process' && processInput) {
            const processValue = processInput.value.trim();
            if (!processValue) {
                showToast('请输入进程名称', 'warning');
                return;
            }
            processName = processValue.startsWith(':') ? processValue : ':' + processValue;
        } else if (type === 'thread' && threadInput) {
            const threadValue = threadInput.value.trim();
            if (!threadValue) {
                showToast('请输入线程名称', 'warning');
                return;
            }
            threadName = threadValue;
        }

        // 更新绑定
        appBindings[index] = {
            ...appBindings[index],
            packageName: packageName,
            processName: processName,
            threadName: threadName,
            cores: cores
        };

        // 更新UI
        updateBindingsList();

        // 更新智能建议列表
        if (typeof updateSuggestions === 'function') {
            updateSuggestions();
        }

        // 隐藏模态框
        hideModal('edit-binding-modal');

        // 显示提示
        showToast('规则已更新', 'success');

        // 如果开启了自动保存，则保存配置
        if (CONFIG.AUTO_SAVE) {
            saveConfig();
        }
    }
}

/**
 * 保存应用名称
 */
function saveAppName() {
    const nameInput = document.getElementById('edit-app-name');
    const packageInput = document.getElementById('edit-package');

    if (!packageInput || !nameInput) return;

    const packageName = packageInput.value.trim();
    const appName = nameInput.value.trim();

    if (!packageName) {
        showToast('包名不能为空', 'warning');
        return;
    }

    // 更新应用名
    if (appName) {
        appNames[packageName] = appName;
    } else {
        // 如果名称为空，删除映射
        delete appNames[packageName];
    }

    // 更新UI
    updateBindingsList();

    // 隐藏模态框
    hideModal('edit-name-modal');

    // 显示提示
    showToast('应用名称已更新', 'success');

    // 如果开启了自动保存，则保存配置
    if (CONFIG.AUTO_SAVE) {
        saveConfig();
    }
}

/**
 * 添加新规则到现有应用
 */
function addNewRules() {
    // 获取应用信息
    const packageElement = document.getElementById('rule-app-package');
    if (!packageElement) return;

    const packageName = packageElement.textContent.trim();
    if (!packageName) {
        showToast('应用包名不能为空', 'warning');
        return;
    }

    // 获取所有规则
    const processItems = document.querySelectorAll('#rule-process-list .process-item');
    let hasValidRule = false;

    // 检查至少有一条有效规则
    processItems.forEach(item => {
        const typeRadio = item.querySelector('.binding-type-radio:checked');
        const coresInput = item.querySelector('.binding-cores');

        if (typeRadio && coresInput && coresInput.value.trim()) {
            hasValidRule = true;
        }
    });

    if (!hasValidRule) {
        showToast('请至少添加一条有效规则', 'warning');
        return;
    }

    // 处理每条规则
    let addedCount = 0;
    processItems.forEach(item => {
        const typeRadio = item.querySelector('.binding-type-radio:checked');
        const nameInput = item.querySelector('.binding-name');
        const coresInput = item.querySelector('.binding-cores');

        if (!typeRadio || !coresInput || !coresInput.value.trim()) {
            return; // 跳过无效规则
        }

        const type = typeRadio.value;
        const name = nameInput.value.trim();
        const cores = coresInput.value.trim();

        // 验证核心格式
        if (!validateCoreInput(cores)) {
            showToast('核心格式无效，请检查', 'error');
            return;
        }

        // 创建绑定规则
        let processName = '';
        let threadName = '';

        if (type === 'process') {
            processName = name ? (name.startsWith(':') ? name : ':' + name) : '';
        } else if (type === 'thread') {
            threadName = name;
        }

        // 跳过无效的子进程或线程
        if ((type === 'process' && !processName) || (type === 'thread' && !threadName)) {
            showToast('请输入进程/线程名称', 'warning');
            return;
        }

        // 添加到绑定列表
        appBindings.push({
            packageName: packageName,
            processName: processName,
            threadName: threadName,
            cores: cores,
            comment: '',
            enabled: true, // 默认启用
            id: generateId()
        });

        addedCount++;
    });

    if (addedCount === 0) {
        showToast('没有添加任何有效规则', 'warning');
        return;
    }

    // 更新UI
    updateBindingsList();

    // 更新智能建议列表
    if (typeof updateSuggestions === 'function') {
        updateSuggestions();
    }

    // 隐藏模态框
    hideModal('add-rule-modal');

    // 显示提示
    showToast(`已添加 ${addedCount} 条规则`, 'success');

    // 如果开启了自动保存，则保存配置
    if (CONFIG.AUTO_SAVE) {
        saveConfig();
    }
}

/**
 * 显示编辑应用名模态框
 * @param {string} packageName - 应用包名
 */
function showEditNameModal(packageName) {
    const modal = document.getElementById('edit-name-modal');
    if (!modal) return;

    const nameInput = document.getElementById('edit-app-name');
    const packageInput = document.getElementById('edit-package');

    if (nameInput) nameInput.value = appNames[packageName] || '';
    if (packageInput) {
        packageInput.value = packageName;

        // 处理长包名的显示
        if (packageName.length > 40) {
            packageInput.setAttribute('title', packageName);
        }
    }

    // 记录当前编辑的包名
    currentEditPackage = packageName;

    // 显示模态框
    showModal('edit-name-modal');
}

/**
 * 更新应用绑定列表
 * @param {string} searchText - 搜索文本
 */
function updateBindingsList(searchText = '') {
    const appListContainer = document.getElementById('app-list');
    const emptyState = document.getElementById('empty-state');

    if (!appListContainer) return;

    // 清空当前列表
    appListContainer.innerHTML = '';

    // 如果没有应用，显示空状态
    if (appBindings.length === 0) {
        if (emptyState) emptyState.classList.add('active');
        toggleEmptyState(true);
        return;
    }

    // 隐藏空状态
    if (emptyState) emptyState.classList.remove('active');
    toggleEmptyState(false);

    // 按包名对绑定进行分组
    const bindingsByPackage = {};
    for (const binding of appBindings) {
        if (!bindingsByPackage[binding.packageName]) {
            bindingsByPackage[binding.packageName] = [];
        }
        bindingsByPackage[binding.packageName].push(binding);
    }

    // 应用包名列表
    const packageNames = Object.keys(bindingsByPackage);

    // 按应用名称排序
    packageNames.sort((a, b) => {
        const nameA = appNames[a] || a;
        const nameB = appNames[b] || b;
        return nameA.localeCompare(nameB);
    });

    // 处理搜索
    const filteredPackages = searchText ?
        packageNames.filter(packageName => {
            const appName = appNames[packageName] || '';
            const bindings = bindingsByPackage[packageName];

            // 匹配应用名或包名
            if (appName.toLowerCase().includes(searchText.toLowerCase()) ||
                packageName.toLowerCase().includes(searchText.toLowerCase())) {
                return true;
            }

            // 匹配进程名或线程名
            return bindings.some(binding =>
                (binding.processName && binding.processName.toLowerCase().includes(searchText.toLowerCase())) ||
                (binding.threadName && binding.threadName.toLowerCase().includes(searchText.toLowerCase()))
            );
        }) :
        packageNames;

    // 如果搜索结果为空
    if (filteredPackages.length === 0) {
        toggleEmptySearch(true, searchText);
        return;
    }

    // 隐藏搜索空状态
    toggleEmptySearch(false);

    // 渲染每个应用卡片
    filteredPackages.forEach(packageName => {
        const card = createAppCard(packageName, bindingsByPackage[packageName], searchText);
        appListContainer.appendChild(card);
    });

    // 绑定卡片展开/折叠事件
    bindAppCardEvents();
}