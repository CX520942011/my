// 工具函数

// 全局配置
const CONFIG = {
    CONFIG_FILE_PATH: '/data/adb/modules/AppOpt/applist.conf',
    AUTO_SAVE: false,
    APP_NAME_TOOL: '/data/adb/modules/AppOpt/webroot/tool/appinfo'
};

// 应用范围设置
const APP_SCOPE_STORAGE_KEY = 'appopt_app_scope';
const APP_SCOPE_OPTIONS = {
    user: { flag: '-3', name: '用户应用' },
    system: { flag: '-s', name: '系统应用' },
    all: { flag: '-a', name: '所有应用' }
};

/**
 * 生成唯一ID
 * @returns {string} 唯一ID
 */
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

/**
 * 显示加载动画
 */
function showLoading() {
    document.querySelector('.loading-overlay').classList.add('active');
}

/**
 * 隐藏加载动画
 */
function hideLoading() {
    document.querySelector('.loading-overlay').classList.remove('active');
}

/**
 * 显示提示信息
 * @param {string} message - 提示内容
 * @param {string} type - 提示类型：info, success, error, warning
 * @param {number} duration - 显示时长(毫秒)
 */
function showToast(message, type = 'info', duration = 1000) {
    const container = document.querySelector('.toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    // 处理长文本
    let displayMessage = message;
    const maxToastLength = 50; // 最大显示长度

    if (message.length > maxToastLength) {
        // 检查是否有引号包裹的内容
        if (message.includes('"')) {
            const parts = message.split('"');
            if (parts.length >= 3) {
                // 提取引号内的内容
                const quotedContent = parts[1];

                // 如果引号内容很长，进行截断
                if (quotedContent.length > 25) {
                    displayMessage = parts[0] + '"' + quotedContent.substring(0, 22) + '..."' + (parts[2].length > 10 ? parts[2].substring(0, 10) + '...' : parts[2]);
                } else {
                    // 如果引号内容不长，但整体消息太长
                    displayMessage = parts[0] + '"' + quotedContent + '"' + (parts[2].length > 15 ? parts[2].substring(0, 12) + '...' : parts[2]);
                }
            } else {
                displayMessage = message.substring(0, maxToastLength) + '...';
            }
        } else {
            displayMessage = message.substring(0, maxToastLength) + '...';
        }
    }

    // 添加图标
    let iconName = '';
    switch (type) {
        case 'success': iconName = 'check_circle'; break;
        case 'error': iconName = 'error'; break;
        case 'warning': iconName = 'warning'; break;
        default: iconName = 'info'; break;
    }

    toast.innerHTML = `
        <i class="material-icons-round">${iconName}</i>
        <span title="${message}">${displayMessage}</span>
    `;

    container.appendChild(toast);

    // 自动移除提示
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(100px)';
        setTimeout(() => {
            container.removeChild(toast);
        }, 300);
    }, duration);
}

/**
 * 执行命令
 * @param {string} command - 要执行的命令
 * @returns {Promise<string>} 命令执行结果
 */
async function execCommand(command) {
    const callbackName = `exec_callback_${Date.now()}`;

    return new Promise((resolve, reject) => {
        window[callbackName] = (errno, stdout, stderr) => {
            delete window[callbackName];
            errno === 0 ? resolve(stdout) : reject(stderr || "执行错误");
        };

        try {
            if (typeof ksuApi !== 'undefined' && ksuApi && ksuApi.exec) {
                ksuApi.exec(command, "{}", callbackName);
            } else if (typeof ksu !== 'undefined' && ksu && ksu.exec) {
                // 兼容性处理
                ksu.exec(command, "{}", callbackName);
            } else {
                // 无法访问API时
                console.error("KernelSU API不可用");
                showToast("KernelSU API不可用，请检查权限或刷新页面", "error");
                reject("KernelSU API不可用");
            }
        } catch (error) {
            console.error("执行命令失败:", error);
            showToast("执行命令失败: " + error.message, "error");
            reject(error);
        }
    });
}

/**
 * 验证CPU核心范围格式
 * @param {string} input - 核心范围字符串，例如 "0-3,5-7"
 * @returns {boolean} 格式是否有效
 */
function validateCoreInput(input) {
    if (!input) return false;

    // 允许的格式: "0-3", "0,1,2,3", "0-2,4,6-7"
    const pattern = /^(\d+(-\d+)?)(,\d+(-\d+)?)*$/;
    return pattern.test(input);
}

/**
 * 初始化主题设置
 * 根据系统主题或用户偏好设置应用主题
 */
function initTheme() {
    // 从本地存储获取主题偏好
    const savedTheme = localStorage.getItem('theme');

    if (savedTheme) {
        // 应用已保存的主题偏好
        applyTheme(savedTheme);
    } else {
        // 跟随系统主题
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        applyTheme(prefersDark ? 'dark' : 'light');
    }

    // 监听系统主题变化
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        // 如果未设置明确的主题偏好，则跟随系统变化
        if (!localStorage.getItem('theme')) {
            applyTheme(e.matches ? 'dark' : 'light');
        }
    });
}

/**
 * 应用主题
 * @param {string} theme - 主题名称：'light' 或 'dark'
 */
function applyTheme(theme) {
    const body = document.body;
    const themeToggle = document.getElementById('theme-toggle');

    if (theme === 'dark') {
        body.classList.add('dark-mode');
        if (themeToggle) themeToggle.innerHTML = '<i class="material-icons-round">light_mode</i>';
    } else {
        body.classList.remove('dark-mode');
        if (themeToggle) themeToggle.innerHTML = '<i class="material-icons-round">dark_mode</i>';
    }
}

/**
 * 切换主题
 */
function toggleTheme() {
    const isDarkMode = document.body.classList.contains('dark-mode');
    const newTheme = isDarkMode ? 'light' : 'dark';

    // 保存用户主题偏好
    localStorage.setItem('theme', newTheme);

    // 应用新主题
    applyTheme(newTheme);
}

/**
 * 检查是否为空对象
 * @param {Object} obj - 要检查的对象
 * @returns {boolean} 是否为空对象
 */
function isEmptyObject(obj) {
    return obj && Object.keys(obj).length === 0 && obj.constructor === Object;
}

/**
 * 处理文本溢出
 * @param {HTMLElement} element - DOM元素
 * @param {number} maxLength - 最大长度
 */
function handleTextOverflow(element, maxLength) {
    if (element.textContent.length > maxLength) {
        element.title = element.textContent;
        element.textContent = element.textContent.substring(0, maxLength) + '...';
    }
}

/**
 * 防抖函数
 * @param {Function} func - 要执行的函数
 * @param {number} wait - 等待时间(毫秒)
 * @returns {Function} 防抖后的函数
 */
function debounce(func, wait = 300) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            func.apply(this, args);
        }, wait);
    };
}

/**
 * 获取类型标签HTML
 * @param {string} type - 绑定类型：main, process, thread
 * @returns {string} HTML字符串
 */
function getTypeTagHtml(type) {
    const typeIcons = {
        main: 'layers',
        process: 'select_all',
        thread: 'fiber_manual_record'
    };

    const typeNames = {
        main: '主进程',
        process: '子进程',
        thread: '线程'
    };

    return `
        <div class="binding-type-tag type-${type}">
            <i class="material-icons-round">${typeIcons[type] || 'layers'}</i>
            ${typeNames[type] || '主进程'}
        </div>
    `;
}

/**
 * 格式化错误信息
 * @param {Error|string} error - 错误对象或错误消息
 * @returns {string} 格式化后的错误消息
 */
function formatError(error) {
    if (typeof error === 'string') return error;
    if (error instanceof Error) return error.message;
    return '未知错误';
}

// 存储应用名称到包名的映射
let appNameToPackageMap = new Map();

/**
 * 获取应用列表
 * 使用appinfo工具获取应用信息
 */
async function fetchAppList() {
    try {
        // 检查appinfo工具是否存在并设置权限
        const checkAndSetupResult = await execCommand(`
            if [ -f ${CONFIG.APP_NAME_TOOL} ]; then
                chmod +x ${CONFIG.APP_NAME_TOOL} 2>/dev/null
                echo "ready"
            else
                echo "not_exists"
            fi
        `);

        if (checkAndSetupResult.trim() !== 'ready') {
            showToast('appinfo工具不存在', 'warning');
            return false;
        }

        // 使用appinfo工具获取应用的包名和应用名称
        // -o pn,an: 输出包名和应用名称
        // 动态获取应用范围标志
        // -d ",": 设置分隔符为逗号
        const scopeFlag = getAppScopeFlag();
        const toolResult = await execCommand(`${CONFIG.APP_NAME_TOOL} -o pn,an -d "," ${scopeFlag}`);

        // 检查工具执行结果
        if (!toolResult || toolResult.trim().length === 0) {
            showToast('appinfo工具未返回数据', 'warning');
            return false;
        }

        if (toolResult.includes('error') || toolResult.includes('Error') || toolResult.includes('!')) {
            showToast(`appinfo工具执行出错: ${toolResult}`, 'error');
            return false;
        }

        // 直接解析appinfo的输出
        parseAppInfoOutput(toolResult);
        return true;

    } catch (error) {
        showToast(`获取应用列表失败: ${error}`, 'error');
        return false;
    }
}

/**
 * 解析appinfo工具的输出
 * @param {string} output - appinfo工具的输出内容
 */
function parseAppInfoOutput(output) {
    appNameToPackageMap.clear();

    try {
        // 按行分割输出
        const lines = output.trim().split('\n');

        for (const line of lines) {
            const trimmedLine = line.trim();

            // 跳过空行
            if (!trimmedLine) continue;

            // 查找逗号分隔符
            const commaIndex = trimmedLine.indexOf(',');
            if (commaIndex === -1) continue;

            // 提取包名和应用名称
            const packageName = trimmedLine.substring(0, commaIndex).trim();
            const appName = trimmedLine.substring(commaIndex + 1).trim();

            // 验证数据有效性
            if (packageName && appName && appName !== '未知应用') {
                appNameToPackageMap.set(appName, packageName);
            }
        }

        console.log(`已解析 ${appNameToPackageMap.size} 个应用信息`);
    } catch (error) {
        console.error('解析appinfo输出失败:', error);
        showToast('解析应用信息失败', 'error');
    }
}

/**
 * 根据应用名称获取包名
 * @param {string} appName - 应用名称
 * @returns {string|null} 包名或null
 */
function getPackageByAppName(appName) {
    return appNameToPackageMap.get(appName) || null;
}

/**
 * 获取所有应用名称
 * @returns {Array<string>} 应用名称数组
 */
function getAllAppNames() {
    return Array.from(appNameToPackageMap.keys());
}

/**
 * 获取当前应用范围设置
 * @returns {string} 应用范围 ('user', 'system', 'all')
 */
function getAppScope() {
    return localStorage.getItem(APP_SCOPE_STORAGE_KEY) || 'user';
}

/**
 * 设置应用范围
 * @param {string} scope - 应用范围 ('user', 'system', 'all')
 */
function setAppScope(scope) {
    if (APP_SCOPE_OPTIONS[scope]) {
        localStorage.setItem(APP_SCOPE_STORAGE_KEY, scope);
    }
}

/**
 * 获取当前应用范围的显示名称
 * @returns {string} 显示名称
 */
function getAppScopeName() {
    const scope = getAppScope();
    return APP_SCOPE_OPTIONS[scope]?.name || '用户应用';
}

/**
 * 获取当前应用范围的appinfo命令标志
 * @returns {string} 命令标志
 */
function getAppScopeFlag() {
    const scope = getAppScope();
    return APP_SCOPE_OPTIONS[scope]?.flag || '-3';
}

