// 智能输入建议

// 已知的进程和线程名称
let knownProcessNames = new Set();
let knownThreadNames = new Set();

// 初始化智能建议
function initSuggestions() {
    // 收集现有配置中的进程和线程名称
    collectExistingNames();

    // 为编辑绑定模态框中的输入框添加自动补全
    setupAutoComplete('#edit-binding-process', knownProcessNames);
    setupAutoComplete('#edit-binding-thread', knownThreadNames);

    // 为添加应用模态框中的动态添加的输入框设置事件委托
    setupDynamicAutoComplete();

    // 为应用名称输入框添加自动补全
    setupAppNameAutoComplete();

    // 监听窗口大小变化，更新下拉菜单位置
    window.addEventListener('resize', debounce(updateDropdownPositions, 200));
}

/**
 * 更新所有下拉菜单的位置
 */
function updateDropdownPositions() {
    const isMobile = isMobileDevice();

    // 更新所有下拉菜单
    document.querySelectorAll('.autocomplete-dropdown').forEach(dropdown => {
        if (isMobile) {
            dropdown.classList.add('mobile');
        } else {
            dropdown.classList.remove('mobile');
        }
    });
}

/**
 * 从现有配置中收集进程和线程名称
 */
function collectExistingNames() {
    // 清空现有集合
    knownProcessNames.clear();
    knownThreadNames.clear();

    // 遍历所有绑定规则
    appBindings.forEach(binding => {
        // 收集进程名称（去掉前缀冒号）
        if (binding.processName) {
            const processName = binding.processName.startsWith(':') ?
                binding.processName.substring(1) : binding.processName;
            knownProcessNames.add(processName);
        }

        // 收集线程名称
        if (binding.threadName) {
            knownThreadNames.add(binding.threadName);
        }
    });

    console.log(`已收集 ${knownProcessNames.size} 个进程名称和 ${knownThreadNames.size} 个线程名称`);
}

/**
 * 为指定输入框设置自动补全功能
 * @param {string} selector - 输入框选择器
 * @param {Set} suggestions - 建议列表
 */
function setupAutoComplete(selector, suggestions) {
    const inputElement = document.querySelector(selector);
    if (!inputElement) return;

    // 创建下拉容器
    let dropdownContainer = document.createElement('div');
    dropdownContainer.className = 'autocomplete-dropdown';
    inputElement.parentNode.style.position = 'relative';

    // 检测是否为移动设备
    if (isMobileDevice()) {
        dropdownContainer.classList.add('mobile');
    }

    inputElement.parentNode.appendChild(dropdownContainer);

    // 输入框获得焦点时检查设备类型
    inputElement.addEventListener('focus', function() {
        if (isMobileDevice()) {
            dropdownContainer.classList.add('mobile');
        } else {
            dropdownContainer.classList.remove('mobile');
        }
    });

    // 输入事件处理
    inputElement.addEventListener('input', function() {
        const inputValue = this.value.trim().toLowerCase();

        // 清空下拉列表
        dropdownContainer.innerHTML = '';

        // 如果输入为空，隐藏下拉列表
        if (!inputValue) {
            dropdownContainer.style.display = 'none';
            return;
        }

        // 过滤匹配的建议 - 从前向后匹配
        const matchedSuggestions = Array.from(suggestions)
            .filter(item => item.toLowerCase().startsWith(inputValue))
            // 按匹配度排序：完全匹配的排在前面，然后按字母顺序排序
            .sort((a, b) => {
                const aExact = a.toLowerCase() === inputValue;
                const bExact = b.toLowerCase() === inputValue;

                if (aExact && !bExact) return -1;
                if (!aExact && bExact) return 1;
                return a.localeCompare(b);
            });

        // 如果没有匹配项，隐藏下拉列表
        if (matchedSuggestions.length === 0) {
            dropdownContainer.style.display = 'none';
            return;
        }

        // 显示匹配的建议（最多显示10个）
        matchedSuggestions.slice(0, 10).forEach(suggestion => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';

            // 高亮匹配部分 - 只高亮开头
            const inputLength = inputValue.length;
            const highlightedText = `<strong>${suggestion.substring(0, inputLength)}</strong>${suggestion.substring(inputLength)}`;

            item.innerHTML = highlightedText;

            // 点击事件
            item.addEventListener('click', function() {
                inputElement.value = suggestion;
                dropdownContainer.style.display = 'none';
                inputElement.focus();
            });

            dropdownContainer.appendChild(item);
        });

        // 显示下拉列表
        dropdownContainer.style.display = 'block';
    });

    // 失去焦点时隐藏下拉列表（延迟处理，以便点击下拉项有效）
    inputElement.addEventListener('blur', function() {
        setTimeout(() => {
            dropdownContainer.style.display = 'none';
        }, 200);
    });

    // 键盘导航
    inputElement.addEventListener('keydown', function(e) {
        const items = dropdownContainer.querySelectorAll('.autocomplete-item');
        if (items.length === 0) return;

        // 获取当前选中项
        const activeItem = dropdownContainer.querySelector('.autocomplete-item.active');
        let activeIndex = -1;

        if (activeItem) {
            activeIndex = Array.from(items).indexOf(activeItem);
        }

        // 向下箭头
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            activeIndex = (activeIndex + 1) % items.length;
            updateActiveItem(items, activeIndex);
        }
        // 向上箭头
        else if (e.key === 'ArrowUp') {
            e.preventDefault();
            activeIndex = (activeIndex - 1 + items.length) % items.length;
            updateActiveItem(items, activeIndex);
        }
        // 回车键
        else if (e.key === 'Enter' && activeItem) {
            e.preventDefault();
            this.value = activeItem.textContent;
            dropdownContainer.style.display = 'none';
        }
        // Escape键
        else if (e.key === 'Escape') {
            dropdownContainer.style.display = 'none';
        }
    });
}

/**
 * 更新下拉列表中的活动项
 * @param {NodeList} items - 所有下拉项
 * @param {number} activeIndex - 活动项索引
 */
function updateActiveItem(items, activeIndex) {
    // 移除所有活动状态
    items.forEach(item => item.classList.remove('active'));

    // 设置新的活动项
    if (activeIndex >= 0 && activeIndex < items.length) {
        items[activeIndex].classList.add('active');
        items[activeIndex].scrollIntoView({ block: 'nearest' });
    }
}

/**
 * 为动态添加的输入框设置自动补全（使用事件委托）
 */
function setupDynamicAutoComplete() {
    // 获取进程列表容器
    const processList = document.getElementById('process-list');
    const ruleProcessList = document.getElementById('rule-process-list');

    // 为添加应用模态框设置事件委托
    if (processList) {
        setupProcessListAutoComplete(processList);
    }

    // 为添加规则模态框设置事件委托
    if (ruleProcessList) {
        setupProcessListAutoComplete(ruleProcessList);
    }
}

/**
 * 为指定的进程列表容器设置自动补全事件委托
 * @param {HTMLElement} processList - 进程列表容器
 */
function setupProcessListAutoComplete(processList) {

    // 使用事件委托监听焦点事件
    processList.addEventListener('focus', function(e) {
        if (e.target && e.target.classList.contains('binding-name')) {
            const processItem = e.target.closest('.process-item');
            if (!processItem) return;

            const dropdownContainer = processItem.querySelector('.autocomplete-dropdown');
            if (dropdownContainer) {
                if (isMobileDevice()) {
                    dropdownContainer.classList.add('mobile');
                } else {
                    dropdownContainer.classList.remove('mobile');
                }
            }
        }
    }, true);

    // 使用事件委托监听输入事件
    processList.addEventListener('input', function(e) {
        // 检查是否是绑定名称输入框
        if (e.target && e.target.classList.contains('binding-name')) {
            const processItem = e.target.closest('.process-item');
            if (!processItem) return;

            // 获取绑定类型
            const typeRadio = processItem.querySelector('.binding-type-radio:checked');
            if (!typeRadio) return;

            const type = typeRadio.value;

            // 根据类型决定使用哪个建议集
            const suggestions = type === 'process' ? knownProcessNames : knownThreadNames;

            // 创建或获取下拉容器
            let dropdownContainer = processItem.querySelector('.autocomplete-dropdown');
            if (!dropdownContainer) {
                dropdownContainer = document.createElement('div');
                dropdownContainer.className = 'autocomplete-dropdown';

                // 检测是否为移动设备
                if (isMobileDevice()) {
                    dropdownContainer.classList.add('mobile');
                }

                e.target.parentNode.style.position = 'relative';
                e.target.parentNode.appendChild(dropdownContainer);
            }

            const inputValue = e.target.value.trim().toLowerCase();

            // 清空下拉列表
            dropdownContainer.innerHTML = '';

            // 如果输入为空，隐藏下拉列表
            if (!inputValue) {
                dropdownContainer.style.display = 'none';
                return;
            }

            // 过滤匹配的建议 - 从前向后匹配
            const matchedSuggestions = Array.from(suggestions)
                .filter(item => item.toLowerCase().startsWith(inputValue))
                // 按匹配度排序：完全匹配的排在前面，然后按字母顺序排序
                .sort((a, b) => {
                    const aExact = a.toLowerCase() === inputValue;
                    const bExact = b.toLowerCase() === inputValue;

                    if (aExact && !bExact) return -1;
                    if (!aExact && bExact) return 1;
                    return a.localeCompare(b);
                });

            // 如果没有匹配项，隐藏下拉列表
            if (matchedSuggestions.length === 0) {
                dropdownContainer.style.display = 'none';
                return;
            }

            // 显示匹配的建议（最多显示10个）
            matchedSuggestions.slice(0, 10).forEach(suggestion => {
                const item = document.createElement('div');
                item.className = 'autocomplete-item';

                // 高亮匹配部分 - 只高亮开头
                const inputLength = inputValue.length;
                const highlightedText = `<strong>${suggestion.substring(0, inputLength)}</strong>${suggestion.substring(inputLength)}`;

                item.innerHTML = highlightedText;

                // 点击事件
                item.addEventListener('click', function() {
                    e.target.value = suggestion;
                    dropdownContainer.style.display = 'none';
                    e.target.focus();
                });

                dropdownContainer.appendChild(item);
            });

            // 显示下拉列表
            dropdownContainer.style.display = 'block';
        }
    });

    // 处理失去焦点事件
    processList.addEventListener('blur', function(e) {
        if (e.target && e.target.classList.contains('binding-name')) {
            const processItem = e.target.closest('.process-item');
            if (!processItem) return;

            const dropdownContainer = processItem.querySelector('.autocomplete-dropdown');
            if (dropdownContainer) {
                setTimeout(() => {
                    dropdownContainer.style.display = 'none';
                }, 200);
            }
        }
    }, true);

    // 处理键盘导航
    processList.addEventListener('keydown', function(e) {
        if (e.target && e.target.classList.contains('binding-name')) {
            const processItem = e.target.closest('.process-item');
            if (!processItem) return;

            const dropdownContainer = processItem.querySelector('.autocomplete-dropdown');
            if (!dropdownContainer) return;

            const items = dropdownContainer.querySelectorAll('.autocomplete-item');
            if (items.length === 0) return;

            // 获取当前选中项
            const activeItem = dropdownContainer.querySelector('.autocomplete-item.active');
            let activeIndex = -1;

            if (activeItem) {
                activeIndex = Array.from(items).indexOf(activeItem);
            }

            // 向下箭头
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                activeIndex = (activeIndex + 1) % items.length;
                updateActiveItem(items, activeIndex);
            }
            // 向上箭头
            else if (e.key === 'ArrowUp') {
                e.preventDefault();
                activeIndex = (activeIndex - 1 + items.length) % items.length;
                updateActiveItem(items, activeIndex);
            }
            // 回车键
            else if (e.key === 'Enter' && activeItem) {
                e.preventDefault();
                e.target.value = activeItem.textContent;
                dropdownContainer.style.display = 'none';
            }
            // Escape键
            else if (e.key === 'Escape') {
                dropdownContainer.style.display = 'none';
            }
        }
    });
}

/**
 * 转义正则表达式特殊字符
 * @param {string} string - 需要转义的字符串
 * @returns {string} 转义后的字符串
 */
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * 检测是否为移动设备
 * @returns {boolean} 是否为移动设备
 */
function isMobileDevice() {
    return window.innerWidth <= 768;
}

/**
 * 更新建议列表
 * 在配置变更后调用此函数刷新建议列表
 */
function updateSuggestions() {
    collectExistingNames();
}

/**
 * 高亮匹配的文本
 * @param {string} text - 原始文本
 * @param {string} searchText - 搜索文本
 * @returns {string} 高亮后的HTML文本
 */
function highlightMatchedText(text, searchText) {
    if (!searchText || !text) return text;

    // 转义搜索文本中的特殊字符
    const escapedSearchText = searchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    // 创建正则表达式，不区分大小写
    const regex = new RegExp(`(${escapedSearchText})`, 'gi');

    // 替换匹配的文本为带strong标签的文本
    return text.replace(regex, '<strong>$1</strong>');
}

/**
 * 为应用名称输入框设置自动补全
 */
function setupAppNameAutoComplete() {
    // 延迟初始化，确保DOM元素已经存在
    setTimeout(() => {
        // 为添加应用模态框中的应用名称输入框设置自动补全
        setupAppNameInput('#new-app-name', '#new-app-package');

        // 为编辑应用模态框中的应用名称输入框设置自动补全
        setupAppNameInput('#edit-app-name', '#edit-package');
    }, 100);
}

/**
 * 为指定的应用名称输入框设置自动补全
 * @param {string} nameInputSelector - 应用名称输入框选择器
 * @param {string} packageInputSelector - 包名输入框选择器
 */
function setupAppNameInput(nameInputSelector, packageInputSelector) {
    const nameInput = document.querySelector(nameInputSelector);
    const packageInput = document.querySelector(packageInputSelector);

    if (!nameInput || !packageInput) return;

    // 清理可能存在的旧下拉菜单容器
    const nameContainer = nameInput.parentElement;
    const oldNameDropdown = nameContainer.querySelector('.autocomplete-dropdown');
    if (oldNameDropdown) {
        oldNameDropdown.remove();
    }

    // 清理包名输入框下的旧容器
    const packageContainer = packageInput.parentElement;
    const oldPackageDropdown = packageContainer.querySelector('.autocomplete-dropdown');
    if (oldPackageDropdown) {
        oldPackageDropdown.remove();
    }

    // 创建下拉菜单容器，放在应用名称输入框下方
    let dropdownContainer = nameContainer.querySelector('.autocomplete-dropdown');

    if (dropdownContainer) {
        dropdownContainer.remove();
    }

    dropdownContainer = document.createElement('div');
    dropdownContainer.className = 'autocomplete-dropdown app-name-dropdown';

    // 移动端特殊处理
    if (isMobileDevice()) {
        dropdownContainer.classList.add('mobile');
    }

    nameContainer.style.position = 'relative';
    nameContainer.appendChild(dropdownContainer);

    // 添加调试信息
    dropdownContainer.setAttribute('data-debug', `应用名称补全-${nameInputSelector}`);

    // 输入事件处理
    nameInput.addEventListener('input', function() {
        const inputValue = this.value.trim();

        // 清空下拉列表
        dropdownContainer.innerHTML = '';

        // 如果输入为空，隐藏下拉列表
        if (!inputValue) {
            dropdownContainer.style.display = 'none';
            return;
        }

        // 获取所有应用名称
        const allAppNames = getAllAppNames();

        // 过滤匹配的应用名称 - 模糊匹配
        const matchedNames = allAppNames
            .filter(name => name.toLowerCase().includes(inputValue.toLowerCase()))
            .sort((a, b) => {
                const aLower = a.toLowerCase();
                const bLower = b.toLowerCase();
                const inputLower = inputValue.toLowerCase();

                // 完全匹配的排在最前面
                const aExact = aLower === inputLower;
                const bExact = bLower === inputLower;
                if (aExact && !bExact) return -1;
                if (!aExact && bExact) return 1;

                // 前缀匹配的排在模糊匹配前面
                const aStartsWith = aLower.startsWith(inputLower);
                const bStartsWith = bLower.startsWith(inputLower);
                if (aStartsWith && !bStartsWith) return -1;
                if (!aStartsWith && bStartsWith) return 1;

                // 匹配位置越靠前的排在前面
                const aIndex = aLower.indexOf(inputLower);
                const bIndex = bLower.indexOf(inputLower);
                if (aIndex !== bIndex) return aIndex - bIndex;

                // 最后按字母顺序排序
                return a.localeCompare(b);
            });

        // 如果没有匹配项，隐藏下拉列表
        if (matchedNames.length === 0) {
            dropdownContainer.style.display = 'none';
            return;
        }

        // 显示匹配的应用名称（最多显示10个）
        matchedNames.slice(0, 10).forEach(appName => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';

            // 高亮匹配部分 - 模糊匹配高亮
            const highlightedText = highlightMatchedText(appName, inputValue);

            item.innerHTML = highlightedText;

            // 点击事件
            item.addEventListener('click', function() {
                nameInput.value = appName;
                dropdownContainer.style.display = 'none';

                // 自动填充对应的包名
                const packageName = getPackageByAppName(appName);
                if (packageName && !packageInput.readOnly) {
                    packageInput.value = packageName;
                    showToast(`已自动填充包名: ${packageName}`, 'success', 2000);
                }

                nameInput.focus();
            });

            dropdownContainer.appendChild(item);
        });

        // 显示下拉列表
        dropdownContainer.style.display = 'block';
    });

    // 失去焦点时隐藏下拉列表
    nameInput.addEventListener('blur', function() {
        setTimeout(() => {
            dropdownContainer.style.display = 'none';
        }, 200);
    });

    // 键盘导航
    nameInput.addEventListener('keydown', function(e) {
        const items = dropdownContainer.querySelectorAll('.autocomplete-item');
        if (items.length === 0) return;

        // 获取当前选中项
        const activeItem = dropdownContainer.querySelector('.autocomplete-item.active');
        let activeIndex = -1;

        if (activeItem) {
            activeIndex = Array.from(items).indexOf(activeItem);
        }

        // 向下箭头
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            activeIndex = (activeIndex + 1) % items.length;
            updateActiveItem(items, activeIndex);
        }
        // 向上箭头
        else if (e.key === 'ArrowUp') {
            e.preventDefault();
            activeIndex = (activeIndex - 1 + items.length) % items.length;
            updateActiveItem(items, activeIndex);
        }
        // 回车键
        else if (e.key === 'Enter' && activeItem) {
            e.preventDefault();
            const appName = activeItem.textContent;
            nameInput.value = appName;
            dropdownContainer.style.display = 'none';

            // 自动填充对应的包名
            const packageName = getPackageByAppName(appName);
            if (packageName && !packageInput.readOnly) {
                packageInput.value = packageName;
                showToast(`已自动填充包名: ${packageName}`, 'success', 2000);
            }
        }
        // Escape键
        else if (e.key === 'Escape') {
            dropdownContainer.style.display = 'none';
        }
    });
}
