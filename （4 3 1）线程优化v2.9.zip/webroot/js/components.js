// UI组件

// 显示空状态提示
function toggleEmptyState(show, message = null) {
    const emptyState = document.getElementById('empty-state');
    if (!emptyState) return;

    if (show) {
        emptyState.classList.add('active');

        // 如果提供了自定义消息
        if (message) {
            const messageEl = emptyState.querySelector('p');
            if (messageEl) messageEl.textContent = message;
        }
    } else {
        emptyState.classList.remove('active');
    }
}

// 显示搜索结果空状态
function toggleEmptySearch(show, searchText = '') {
    const appList = document.getElementById('app-list');
    if (!appList) return;

    // 移除已有的空搜索提示
    const existingEmpty = appList.querySelector('.empty-search');
    if (existingEmpty) {
        appList.removeChild(existingEmpty);
    }

    if (show) {
        const emptySearch = document.createElement('div');
        emptySearch.className = 'empty-search';
        emptySearch.innerHTML = `
            <i class="material-icons-round">search_off</i>
            <p>没有找到与"${searchText}"匹配的内容</p>
        `;
        appList.appendChild(emptySearch);
    }
}

// 截断过长文本
function truncateText(text, maxLength) {
    if (!text || text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

// 处理长应用名显示
function handleLongAppNames(element) {
    if (!element) return;

    const appName = element.querySelector('.app-name');
    const appPackage = element.querySelector('.app-package');

    if (appName) {
        const originalText = appName.textContent;
        if (originalText.length > 18) {
            appName.setAttribute('title', originalText);
            appName.textContent = truncateText(originalText, 18);
        }
    }

    if (appPackage) {
        const originalText = appPackage.textContent;
        if (originalText.length > 28) {
            appPackage.setAttribute('title', originalText);
            appPackage.textContent = truncateText(originalText, 28);
        }
    }
}

/**
 * 处理长绑定名称的显示
 * @param {HTMLElement} element - 绑定项容器
 */
function handleLongBindingNames(element) {
    if (!element) return;

    const bindingTarget = element.querySelector('.binding-target');

    if (bindingTarget) {
        const originalText = bindingTarget.textContent;
        if (originalText.length > 20) {
            bindingTarget.setAttribute('title', originalText);
            bindingTarget.textContent = truncateText(originalText, 20);
        }
    }
}

/**
 * 创建应用卡片的展开折叠效果
 * @param {HTMLElement} card - 卡片元素
 */
function setupCardAnimation(card) {
    if (!card) return;

    const header = card.querySelector('.app-card-header');
    const body = card.querySelector('.app-card-body');

    if (!header || !body) return;

    // 计算内容高度
    function updateMaxHeight() {
        if (card.classList.contains('expanded')) {
            const bindingList = body.querySelector('.binding-list');
            if (bindingList) {
                // 计算实际内容高度
                const contentHeight = bindingList.offsetHeight + 32; // 32 for padding

                // 根据屏幕大小调整最大高度比例
                let maxHeightRatio = 0.7; // 默认70vh
                if (window.innerWidth <= 480) {
                    maxHeightRatio = 0.5; // 小屏幕50vh
                } else if (window.innerWidth <= 768) {
                    maxHeightRatio = 0.6; // 中等屏幕60vh
                }

                // 限制最大高度，但允许滚动
                const maxHeight = Math.min(contentHeight, window.innerHeight * maxHeightRatio);
                body.style.maxHeight = `${maxHeight}px`;

                // 如果内容超过最大高度，启用滚动
                if (contentHeight > maxHeight) {
                    body.style.overflowY = 'auto';
                } else {
                    body.style.overflowY = 'hidden';
                }
            } else {
                body.style.maxHeight = '0';
                body.style.overflowY = 'hidden';
            }
        } else {
            body.style.maxHeight = '0';
            body.style.overflowY = 'hidden';
        }
    }

    // 初始设置
    updateMaxHeight();

    // 监听展开/折叠状态变化
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'class') {
                setTimeout(updateMaxHeight, 50); // 延迟一点确保DOM更新完成
            }
        });
    });

    observer.observe(card, { attributes: true });

    // 监听窗口大小变化
    window.addEventListener('resize', debounce(() => {
        if (card.classList.contains('expanded')) {
            updateMaxHeight();
        }
    }, 100));
}

/**
 * 应用平滑滚动到指定元素
 * @param {HTMLElement} element - 目标元素
 * @param {Object} options - 滚动选项
 */
function smoothScrollTo(element, options = {}) {
    if (!element) return;

    const defaultOptions = {
        behavior: 'smooth',
        block: 'nearest',
        inline: 'nearest'
    };

    element.scrollIntoView({ ...defaultOptions, ...options });
}

/**
 * 高亮显示搜索匹配文本
 * @param {string} text - 原始文本
 * @param {string} searchText - 搜索文本
 * @returns {string} 包含高亮HTML的文本
 */
function highlightText(text, searchText) {
    if (!searchText || !text) return text;

    const regex = new RegExp(`(${escapeRegExp(searchText)})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
}

/**
 * 转义正则表达式特殊字符
 * @param {string} string - 需要转义的字符串
 * @returns {string} 转义后的字符串
 */
function escapeRegExp(string) {
    return string.replace(/[.*+\-?^${}()|[\]\\]/g, '\\$&');
}

/**
 * 添加涟漪效果
 * @param {string} selector - 选择器，用于选择要添加涟漪效果的元素
 */
function addRippleEffect(selector) {
    document.querySelectorAll(selector).forEach(element => {
        element.addEventListener('click', function(e) {
            // 清除可能存在的残留涟漪
            const existingRipples = this.querySelectorAll('.ripple');
            existingRipples.forEach(ripple => ripple.remove());

            const ripple = document.createElement('span');
            ripple.classList.add('ripple');

            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height) * 1.5;

            ripple.style.width = ripple.style.height = `${size}px`;
            ripple.style.left = `${e.clientX - rect.left - size / 2}px`;
            ripple.style.top = `${e.clientY - rect.top - size / 2}px`;

            this.appendChild(ripple);

            // 确保波纹元素在动画结束后被移除
            ripple.addEventListener('animationend', () => {
                if (ripple && ripple.parentElement) {
                    ripple.remove();
                }
            });
        });
    });
}

/**
 * 格式化CPU核心范围显示
 * @param {string} cores - 核心范围字符串，例如 "0-3,5-7"
 * @returns {string} 格式化后的显示字符串
 */
function formatCoreRange(cores) {
    if (!cores) return '';

    // 解析范围
    const ranges = cores.split(',').map(range => {
        if (range.includes('-')) {
            const [start, end] = range.split('-').map(Number);
            return { start, end };
        } else {
            const single = Number(range);
            return { start: single, end: single };
        }
    });

    // 合并连续范围
    const mergedRanges = [];
    let currentRange = null;

    ranges.sort((a, b) => a.start - b.start).forEach(range => {
        if (!currentRange) {
            currentRange = { ...range };
        } else if (range.start <= currentRange.end + 1) {
            // 扩展当前范围
            currentRange.end = Math.max(currentRange.end, range.end);
        } else {
            // 开始新范围
            mergedRanges.push(currentRange);
            currentRange = { ...range };
        }
    });

    if (currentRange) {
        mergedRanges.push(currentRange);
    }

    // 格式化输出
    return mergedRanges.map(range => {
        if (range.start === range.end) {
            return range.start;
        } else {
            return `${range.start}-${range.end}`;
        }
    }).join(', ');
}

/**
 * 分析并可视化CPU核心分配
 * @param {string} cores - 核心范围字符串
 * @returns {Object} 核心分配分析
 */
function analyzeCoreAllocation(cores) {
    if (!cores) return null;

    // 解析范围
    const coreSet = new Set();

    cores.split(',').forEach(range => {
        if (range.includes('-')) {
            const [start, end] = range.split('-').map(Number);
            for (let i = start; i <= end; i++) {
                coreSet.add(i);
            }
        } else {
            coreSet.add(Number(range));
        }
    });

    // 排序
    const coreList = Array.from(coreSet).sort((a, b) => a - b);

    // 假设设备有8个核心，分为小核(0-3)和大核(4-7)
    const totalCores = 8;
    const littleCores = coreList.filter(core => core >= 0 && core <= 3);
    const bigCores = coreList.filter(core => core >= 4 && core <= 7);

    return {
        total: coreList.length,
        totalPercent: Math.round((coreList.length / totalCores) * 100),
        littleCores: littleCores.length,
        littleCorePercent: Math.round((littleCores.length / 4) * 100),
        bigCores: bigCores.length,
        bigCorePercent: Math.round((bigCores.length / 4) * 100),
        coreList: coreList
    };
}

// 创建确认对话框
function createConfirmDialog(options = {}) {
    const {
        title = '确认操作',
        message = '确定要执行此操作吗？',
        confirmText = '确定',
        cancelText = '取消',
        onConfirm = () => {},
        onCancel = () => {}
    } = options;

    // 处理超长消息文本
    let displayMessage = message;
    const maxLength = 60; // 确认对话框中消息的最大显示长度

    if (message.length > maxLength) {
        const truncatedPart = message.substring(0, maxLength);
        const messageParts = truncatedPart.split('"');

        // 如果消息中有引号，确保引号前后的内容都能显示
        if (messageParts.length > 2) {
            // 找到第一个和最后一个引号位置
            const firstQuote = message.indexOf('"');
            const lastQuote = message.lastIndexOf('"');

            if (lastQuote > maxLength && lastQuote < message.length) {
                // 显示开头一部分和引号内的内容
                const beforeQuote = message.substring(0, firstQuote);
                const quotedContent = message.substring(firstQuote, lastQuote + 1);

                // 如果引号内容也很长，则截断
                if (quotedContent.length > 30) {
                    displayMessage = beforeQuote + quotedContent.substring(0, 27) + '..."';
                } else {
                    displayMessage = beforeQuote + quotedContent;
                }
            } else {
                displayMessage = truncatedPart + '...';
            }
        } else {
            displayMessage = truncatedPart + '...';
        }
    }

    const dialog = document.createElement('div');
    dialog.className = 'modal confirm-dialog';

    dialog.innerHTML = `
        <div class="modal-wrapper">
            <div class="modal-content confirm-content">
                <div class="confirm-icon">
                    <i class="material-icons-round">warning</i>
                </div>
                <h3>${title}</h3>
                <p title="${message}">${displayMessage}</p>
                <div class="confirm-actions">
                    <button class="btn btn-text cancel-btn">${cancelText}</button>
                    <button class="btn btn-primary confirm-btn">${confirmText}</button>
                </div>
            </div>
        </div>
    `;

    // 添加到文档
    document.body.appendChild(dialog);

    // 绑定事件
    const confirmBtn = dialog.querySelector('.confirm-btn');
    const cancelBtn = dialog.querySelector('.cancel-btn');

    // 确认按钮
    confirmBtn.addEventListener('click', () => {
        onConfirm();
        document.body.removeChild(dialog);
    });

    // 取消按钮
    cancelBtn.addEventListener('click', () => {
        onCancel();
        document.body.removeChild(dialog);
    });

    // 点击背景关闭
    dialog.addEventListener('click', (e) => {
        if (e.target === dialog) {
            onCancel();
            document.body.removeChild(dialog);
        }
    });

    // 显示对话框
    setTimeout(() => {
        dialog.classList.add('active');
    }, 10);

    return dialog;
}

/**
 * 创建底部弹出的确认对话框
 * @param {Object} options - 选项对象
 * @param {string} options.title - 标题
 * @param {string} options.message - 消息内容
 * @param {string} options.confirmText - 确认按钮文本
 * @param {string} options.cancelText - 取消按钮文本
 * @param {Function} options.onConfirm - 确认回调
 * @param {Function} options.onCancel - 取消回调
 * @returns {HTMLElement} 底部确认对话框元素
 */
function createBottomSheetConfirm(options = {}) {
    const {
        title = '确认操作',
        message = '确定要执行此操作吗？',
        confirmText = '确定',
        cancelText = '取消',
        onConfirm = () => {},
        onCancel = () => {}
    } = options;

    // 处理超长消息文本
    let displayMessage = message;
    const maxLength = 60; // 确认对话框中消息的最大显示长度

    if (message.length > maxLength) {
        const truncatedPart = message.substring(0, maxLength);
        const messageParts = truncatedPart.split('"');

        // 如果消息中有引号，确保引号前后的内容都能显示
        if (messageParts.length > 2) {
            // 找到第一个和最后一个引号位置
            const firstQuote = message.indexOf('"');
            const lastQuote = message.lastIndexOf('"');

            if (lastQuote > maxLength && lastQuote < message.length) {
                // 显示开头一部分和引号内的内容
                const beforeQuote = message.substring(0, firstQuote);
                const quotedContent = message.substring(firstQuote, lastQuote + 1);

                // 如果引号内容也很长，则截断
                if (quotedContent.length > 30) {
                    displayMessage = beforeQuote + quotedContent.substring(0, 27) + '..."';
                } else {
                    displayMessage = beforeQuote + quotedContent;
                }
            } else {
                displayMessage = truncatedPart + '...';
            }
        } else {
            displayMessage = truncatedPart + '...';
        }
    }

    // 创建底部确认框元素
    const bottomSheet = document.createElement('div');
    bottomSheet.className = 'bottomsheet-confirm';

    bottomSheet.innerHTML = `
        <div class="bottomsheet-overlay"></div>
        <div class="bottomsheet-content">
            <div class="bottomsheet-pull-indicator"></div>
            <h3 class="bottomsheet-title">${title}</h3>
            <p class="bottomsheet-message">${displayMessage}</p>
            <div class="bottomsheet-actions">
                <button class="btn btn-text cancel-btn">${cancelText}</button>
                <button class="btn btn-primary confirm-btn">${confirmText}</button>
            </div>
        </div>
    `;

    // 添加到文档
    document.body.appendChild(bottomSheet);

    // 绑定事件
    const confirmBtn = bottomSheet.querySelector('.confirm-btn');
    const cancelBtn = bottomSheet.querySelector('.cancel-btn');
    const overlay = bottomSheet.querySelector('.bottomsheet-overlay');
    const content = bottomSheet.querySelector('.bottomsheet-content');

    // 关闭确认框
    const closeBottomSheet = () => {
        bottomSheet.classList.remove('active');
        setTimeout(() => {
            document.body.removeChild(bottomSheet);
        }, 300); // 等待动画完成
    };

    // 确认按钮
    confirmBtn.addEventListener('click', () => {
        onConfirm();
        closeBottomSheet();
    });

    // 取消按钮
    cancelBtn.addEventListener('click', () => {
        onCancel();
        closeBottomSheet();
    });

    // 点击背景或弹框外部区域关闭
    bottomSheet.addEventListener('click', (e) => {
        // 如果点击的是弹框内容区域外的部分，就关闭
        if (!content.contains(e.target) || e.target === overlay) {
            onCancel();
            closeBottomSheet();
        }
    });

    // 触摸滑动关闭功能
    let startY = 0;
    let currentY = 0;

    content.addEventListener('touchstart', (e) => {
        startY = e.touches[0].clientY;
    });

    content.addEventListener('touchmove', (e) => {
        currentY = e.touches[0].clientY;
        const diffY = currentY - startY;

        if (diffY > 0) { // 只允许向下滑动
            content.style.transform = `translateY(${diffY}px)`;
            e.preventDefault(); // 防止页面滚动
        }
    });

    content.addEventListener('touchend', () => {
        if (currentY - startY > 80) { // 如果滑动距离足够
            onCancel();
            closeBottomSheet();
        } else {
            content.style.transform = ''; // 恢复原位
        }
    });

    // 显示确认框
    setTimeout(() => {
        bottomSheet.classList.add('active');
    }, 10);

    return bottomSheet;
}